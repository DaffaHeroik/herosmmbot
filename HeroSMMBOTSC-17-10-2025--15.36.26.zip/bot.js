// bot.js - Full SMM Panel Telegram Bot (referral + layanan + order + admin + broadcast + saldo + history)
// Requirements: npm i node-telegram-bot-api axios
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const axios = require("axios");
const { execSync } = require("child_process");
// ====================== CONFIG ======================
const BOT_TOKEN = "8233756264:AAFdtmUiZKLf3QgVUNHSNm1Z_2ugySOAa8c"; // token bot
const BOT_USERNAME = "heroikzre_smmbot"; // username bot (untuk referral)
const API_ID = 115499;
const API_KEY = "1534tg-vmhgxu-1dbq0a-mnp2ji-zfr7xc";
// raw URL GitHub admins.json (array JSON) - sesuaikan jika perlu
const GITHUB_ADMINS_RAW_URL = "https://raw.githubusercontent.com/DaffaHeroik/herosmmbot/main/admins.json";
// GitHub config for balances and orders
const GITHUB_OWNER = "DaffaHeroik";
const GITHUB_REPO = "herosmmbot";
const GITHUB_BALANCES_PATH = "balances.json";
const GITHUB_ORDERS_PATH = "orders.json";
const GITHUB_TOKEN = "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"; // Ganti dengan GitHub Personal Access Token (PAT) Anda yang memiliki scope repo
const GITHUB_BALANCES_RAW_URL = `https://raw.githubusercontent.com/${GITHUB_OWNER}/${GITHUB_REPO}/main/${GITHUB_BALANCES_PATH}`;
const GITHUB_ORDERS_RAW_URL = `https://raw.githubusercontent.com/${GITHUB_OWNER}/${GITHUB_REPO}/main/${GITHUB_ORDERS_PATH}`;
// local DB files (referrals and users still local)
const REFERRAL_DB = "referral.json";
const USERS_DB = "users.json";
// pagination
const PAGE_SIZE = 5;
// price markup (Rp)
const PRICE_MARKUP = 100; // setiap produk dinaikkan 100
// ====================================================
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
// ======= Helpers: load/save JSON (for local files) =======
function loadJson(path, def) {
  try {
    if (fs.existsSync(path)) return JSON.parse(fs.readFileSync(path));
  } catch (e) { console.error("loadJson error", e); }
  return def;
}
function saveJson(path, obj) {
  fs.writeFileSync(path, JSON.stringify(obj, null, 2));
}
// DB in memory
let referrals = loadJson(REFERRAL_DB, {}); // { chatId: { invitedBy, points, invites:[] } }
let users = new Set(loadJson(USERS_DB, [])); // store chat ids
let balances = {}; // in-memory, fetched/updated via GitHub
let orders = {}; // { chatId: [{ orderId, serviceId, target, quantity, price, timestamp }] }
// persist helpers (local)
function persistUsers() { saveJson(USERS_DB, Array.from(users)); }
function saveReferrals() { saveJson(REFERRAL_DB, referrals); }
// GitHub balances functions (async)
async function initBalances() {
  try {
    const resp = await axios.get(GITHUB_BALANCES_RAW_URL, { timeout: 10000 });
    console.log("Raw balances.json content:", resp.data);
    if (Array.isArray(resp.data)) {
      console.warn("balances.json loaded as array, resetting to empty object");
      balances = {};
      await saveBalancesToGithub();
    } else if (typeof resp.data !== 'object' || resp.data === null) {
      console.warn("balances.json loaded as invalid type, resetting to empty object");
      balances = {};
      await saveBalancesToGithub();
    } else {
      balances = resp.data || {};
    }
    console.log("Balances loaded from GitHub:", balances);
  } catch (e) {
    console.error("initBalances error:", e.message || e);
    balances = {};
    await saveBalancesToGithub();
  }
}
async function saveBalancesToGithub(chatId = null, retries = 3) {
  if (typeof balances !== 'object' || balances === null || Array.isArray(balances)) {
    console.warn("saveBalancesToGithub: balances is invalid, resetting to object");
    balances = {};
  }
  console.log("Saving balances to GitHub:", balances);
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const headers = {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
      };
      const getUrl = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${GITHUB_BALANCES_PATH}`;
      let sha;
      try {
        const getResp = await axios.get(getUrl, { headers, timeout: 10000 });
        sha = getResp.data.sha;
      } catch (e) {
        if (e.response && e.response.status !== 404) {
          throw e;
        }
      }
      const putUrl = getUrl;
      const data = {
        message: 'Update balances.json via bot (attempt ' + attempt + ')',
        content: Buffer.from(JSON.stringify(balances, null, 2)).toString('base64'),
        branch: 'main'
      };
      if (sha) data.sha = sha;
      const response = await axios.put(putUrl, data, { headers, timeout: 15000 });
      console.log("Balances saved to GitHub, commit SHA:", response.data.commit.sha);
      return;
    } catch (e) {
      console.error("saveBalancesToGithub error (attempt " + attempt + "):", e.response ? e.response.data : e.message || e);
      if (attempt === retries) {
        if (chatId) {
          await bot.sendMessage(chatId, `⚠️ Gagal menyimpan saldo ke GitHub: ${e.response?.data?.message || e.message || 'error'}`).catch(()=>{});
        }
        saveJson('balances_backup.json', balances);
        console.log("Saved balances to local backup: balances_backup.json");
        throw e;
      }
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
}
function getBalance(uid) { return balances[uid] || 0; }
async function addBalance(uid, amt, chatId = null) {
  const oldBalance = getBalance(uid);
  balances[uid] = oldBalance + amt;
  console.log(`Balance update for ${uid}: ${oldBalance} -> ${balances[uid]}`);
  await saveBalancesToGithub(chatId);
}
// GitHub orders functions (async)
async function initOrders() {
  try {
    const resp = await axios.get(GITHUB_ORDERS_RAW_URL, { timeout: 10000 });
    console.log("Raw orders.json content:", resp.data);
    if (Array.isArray(resp.data)) {
      console.warn("orders.json loaded as array, resetting to empty object");
      orders = {};
      await saveOrdersToGithub();
    } else if (typeof resp.data !== 'object' || resp.data === null) {
      console.warn("orders.json loaded as invalid type, resetting to empty object");
      orders = {};
      await saveOrdersToGithub();
    } else {
      orders = resp.data || {};
    }
    console.log("Orders loaded from GitHub:", orders);
  } catch (e) {
    console.error("initOrders error:", e.message || e);
    orders = {};
    await saveOrdersToGithub();
  }
}
async function saveOrdersToGithub(chatId = null, retries = 3) {
  if (typeof orders !== 'object' || orders === null || Array.isArray(orders)) {
    console.warn("saveOrdersToGithub: orders is invalid, resetting to object");
    orders = {};
  }
  console.log("Saving orders to GitHub:", orders);
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const headers = {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
      };
      const getUrl = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${GITHUB_ORDERS_PATH}`;
      let sha;
      try {
        const getResp = await axios.get(getUrl, { headers, timeout: 10000 });
        sha = getResp.data.sha;
      } catch (e) {
        if (e.response && e.response.status !== 404) {
          throw e;
        }
      }
      const putUrl = getUrl;
      const data = {
        message: 'Update orders.json via bot (attempt ' + attempt + ')',
        content: Buffer.from(JSON.stringify(orders, null, 2)).toString('base64'),
        branch: 'main'
      };
      if (sha) data.sha = sha;
      const response = await axios.put(putUrl, data, { headers, timeout: 15000 });
      console.log("Orders saved to GitHub, commit SHA:", response.data.commit.sha);
      return;
    } catch (e) {
      console.error("saveOrdersToGithub error (attempt " + attempt + "):", e.response ? e.response.data : e.message || e);
      if (attempt === retries) {
        if (chatId) {
          await bot.sendMessage(chatId, `⚠️ Gagal menyimpan orders ke GitHub: ${e.response?.data?.message || e.message || 'error'}`).catch(()=>{});
        }
        saveJson('orders_backup.json', orders);
        console.log("Saved orders to local backup: orders_backup.json");
        throw e;
      }
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
}
async function addOrder(uid, orderDetails, chatId = null) {
  if (typeof orders !== 'object' || orders === null || Array.isArray(orders)) {
    console.error("addOrder: orders is invalid, resetting to object", orders);
    orders = {};
  }
  if (!orderDetails.orderId || typeof orderDetails.orderId !== 'string' || orderDetails.orderId === 'N/A') {
    console.error("addOrder: Invalid orderId", orderDetails.orderId);
    if (chatId) {
      await bot.sendMessage(chatId, `⚠️ Gagal menyimpan order: ID order tidak valid`).catch(()=>{});
    }
    return false;
  }
  if (!orders[uid]) orders[uid] = [];
  orders[uid].push(orderDetails);
  console.log(`Order added for ${uid}:`, orderDetails);
  await saveOrdersToGithub(chatId);
  return true;
}
// ======= Fetch Order Status =======
async function fetchOrderStatus(orderId) {
  if (!orderId || typeof orderId !== 'string' || orderId === 'N/A') {
    console.warn("fetchOrderStatus: Invalid or missing orderId", orderId);
    return { status: 'invalid_id', remains: 0 };
  }

  const payload = {
    api_id: API_ID,
    api_key: API_KEY,
    id: orderId // <== FIXED HERE
  };

  console.log("fetchOrderStatus: Sending API request with payload:", payload);

  try {
    const resp = await axios.post("https://fayupedia.id/api/status", payload, { timeout: 15000 });
    console.log("fetchOrderStatus: API response for orderId", orderId, ":", resp.data);

    const data = resp.data;

    // Handle single order
    if (data.status && data.order_status) {
      return {
        status: data.order_status,
        remains: data.remains || 0
      };
    }

    // Handle multiple orders
    if (data.status && data.orders) {
      const orderInfo = data.orders[orderId];
      if (orderInfo) {
        return {
          status: orderInfo.order_status || 'unknown',
          remains: orderInfo.remains || 0
        };
      }
    }

    console.warn("fetchOrderStatus: Unexpected API response format", data);
    return { status: 'unknown', remains: 0 };

  } catch (e) {
    console.error("fetchOrderStatus error for orderId", orderId, ":", {
      statusCode: e.response ? e.response.status : null,
      data: e.response ? e.response.data : null,
      message: e.message || e
    });
    return { status: 'error', remains: 0 };
  }
}

// ======= Services cache (fetch from SMM panel) =======
let cacheServices = [];
let lastServicesFetch = 0;
const SERVICES_CACHE_TTL = 60 * 1000; // 60s
function showUserInfo(chatId, user) {
  const userId = user.id;
  const firstName = user.first_name || "";
  const lastName = user.last_name || "";
  const fullName = (firstName + " " + lastName).trim();
  const username = user.username ? "@" + user.username : "(tidak ada username)";
  const teks =
    "🆔 *Informasi Pengguna*\n\n" +
    `👤 Nama: *${fullName}*\n` +
    `🔗 Username: ${username}\n` +
    `💡 User ID: \`${userId}\``;
  bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
}
async function fetchServices() {
  try {
    const now = Date.now();
    if (cacheServices.length && (now - lastServicesFetch) < SERVICES_CACHE_TTL) return cacheServices;
    const resp = await axios.post("https://fayupedia.id/api/services", {
      api_id: API_ID,
      api_key: API_KEY,
    }, { timeout: 15000 });
    if (resp.data && resp.data.services && Array.isArray(resp.data.services)) {
      cacheServices = resp.data.services;
      lastServicesFetch = now;
      return cacheServices;
    } else {
      console.warn("fetchServices: unexpected response", resp.data);
      return [];
    }
  } catch (e) {
    console.error("fetchServices error:", e.message || e);
    return [];
  }
}
// ======= Admin list from GitHub raw =======
async function fetchGithubAdmins() {
  try {
    const resp = await axios.get(GITHUB_ADMINS_RAW_URL, { timeout: 10000 });
    if (typeof resp.data === "string") {
      try {
     
        const parsed = JSON.parse(resp.data);
 console.log(resp.data)
        if (Array.isArray(parsed)) return parsed;
      } catch {
        return resp.data.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
      }
    } else if (Array.isArray(resp.data)) return resp.data;
    return [];
  } catch (e) {
    console.error("fetchGithubAdmins error:", e.message || e);
    return [];
  }
}
// ======= Utilities =======
function escapeMarkdown(text = "") {
  return String(text).replace(/([_*`\[])/g, "\\$1");
}
function makeReferralLink(chatId) {
  return `https://t.me/${BOT_USERNAME}?start=ref_${chatId}`;
}
// track flows
let pendingOrders = {}; // { chatId: { step, service, target, quantity, confirmMessageId, processing } }
let adminPending = {}; // { chatId: { action: 'broadcast'|'topup', temp: ... } }
// ======= Main menu (edit-capable) =======
async function showMainMenu(chatId, msgId = null) {
  const keyboard = [
    [{ text: "📂 Layanan", callback_data: "menu_layanan" }],
    [{ text: "💰 Saldo", callback_data: "menu_saldo" }],
    [{ text: "🧾 Referral", callback_data: "menu_referral" }],
    [{ text: "📜 History Order", callback_data: "menu_history" }],
    [{ text: "👤 Profil", callback_data: "menu_profile" }],
    [{ text: "👑 Admin (login)", callback_data: "menu_admin" }],
  ];
  const text = "👋 Selamat datang di *Heroikzre SMM Bot*!\n\nPilih menu di bawah:";
  if (msgId) {
    return bot.editMessageText(text, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }).catch(async () => {
      await bot.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }).catch(()=>{});
    });
  } else {
    return bot.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }).catch(()=>{});
  }
}
// ======= Show History =======
async function showHistory(chatId, msgId = null) {
  const userOrders = orders[chatId] || [];
  if (!userOrders.length) {
    const text = "⚠️ Tidak ada history order.";
    if (msgId) {
      return bot.editMessageText(text, { chat_id: chatId, message_id: msgId, reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] } }).catch(()=>{});
    } else {
      return bot.sendMessage(chatId, text, { reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] } }).catch(()=>{});
    }
  }
  let teks = "📜 *History Order*\n\n";
  for (const ord of userOrders) {
    const orderId = String(ord.orderId);
    const { status, remains } = await fetchOrderStatus(orderId);
    teks += `🆔 Order: *${orderId}*\nService: ${ord.serviceId}\nTarget: ${escapeMarkdown(ord.target)}\nQuantity: ${ord.quantity}\nHarga: Rp${ord.price}\nWaktu: ${new Date(ord.timestamp).toLocaleString()}\nStatus: *${status}*\nSisa: ${remains}\n\n`;
  }
  if (msgId) {
    return bot.editMessageText(teks, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] } }).catch(async () => {
      await bot.sendMessage(chatId, teks, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] } }).catch(()=>{});
    });
  } else {
    return bot.sendMessage(chatId, teks, { parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] } }).catch(()=>{});
  }
}
// ======= Pagination helpers for categories/subcategories/services =======
async function showCategories(chatId, page = 0, msgId = null) {
  const services = await fetchServices();
  const categories = [...new Set(services.map(s => (s.category || "").split(" ")[0]).filter(Boolean))];
  const start = page * PAGE_SIZE;
  const items = categories.slice(start, start + PAGE_SIZE);
  if (!items.length) {
    return bot.sendMessage(chatId, "⚠️ Tidak ada kategori layanan.").catch(()=>{});
  }
  const keyboard = items.map(c => [{ text: c, callback_data: `cat_${c}` }]);
  const nav = [];
  if (page > 0) nav.push({ text: "⬅️ Prev", callback_data: `catpage_${page - 1}` });
  if (start + PAGE_SIZE < categories.length) nav.push({ text: "Next ➡️", callback_data: `catpage_${page + 1}` });
  if (nav.length) keyboard.push(nav);
  keyboard.push([{ text: "⬅️ Kembali", callback_data: "back_main" }]);
  const text = `📂 Pilih platform (halaman ${page + 1})`;
  if (msgId) {
    return bot.editMessageText(text, { chat_id: chatId, message_id: msgId, reply_markup: { inline_keyboard: keyboard } }).catch(async () => {
      await bot.sendMessage(chatId, text, { reply_markup: { inline_keyboard: keyboard } }).catch(()=>{});
    });
  } else {
    return bot.sendMessage(chatId, text, { reply_markup: { inline_keyboard: keyboard } }).catch(()=>{});
  }
}
async function showSubCategories(chatId, platform, page = 0, msgId = null) {
  const services = await fetchServices();
  const cats = [...new Set(services.filter(s => (s.category || "").startsWith(platform)).map(s => s.category))];
  const start = page * PAGE_SIZE;
  const items = cats.slice(start, start + PAGE_SIZE);
  if (!items.length) return bot.sendMessage(chatId, "⚠️ Tidak ada subkategori.").catch(()=>{});
  const keyboard = items.map(c => [{ text: c.replace(platform + " ", ""), callback_data: `subcat_${encodeURIComponent(c)}` }]);
  const nav = [];
  if (page > 0) nav.push({ text: "⬅️ Prev", callback_data: `subcatpage_${encodeURIComponent(platform)}_${page - 1}` });
  if (start + PAGE_SIZE < cats.length) nav.push({ text: "Next ➡️", callback_data: `subcatpage_${encodeURIComponent(platform)}_${page + 1}` });
  if (nav.length) keyboard.push(nav);
  keyboard.push([{ text: "⬅️ Back", callback_data: "back_platform" }]);
  const text = `📂 Kategori untuk *${escapeMarkdown(platform)}* (halaman ${page + 1})`;
  if (msgId) {
    return bot.editMessageText(text, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }).catch(async () => {
      await bot.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }).catch(()=>{});
    });
  } else {
    return bot.sendMessage(chatId, text, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }).catch(()=>{});
  }
}
async function showServicesPage(chatId, category, page = 0, msgId = null) {
  const services = (await fetchServices()).filter(s => s.category === category);
  const start = page * PAGE_SIZE;
  const items = services.slice(start, start + PAGE_SIZE);
  if (!items.length) return bot.sendMessage(chatId, "⚠️ Tidak ada layanan di kategori ini.").catch(()=>{});
  let teks = `📦 *Layanan ${escapeMarkdown(category)}* (halaman ${page + 1})\n\n`;
  items.forEach(s => {
    const hargaJual = Number(s.price) + PRICE_MARKUP;
    teks += `🆔 *${s.id}* - ${escapeMarkdown(s.name)}\n💰 Rp${hargaJual} / 1000\n📌 Min: ${s.min} | Max: ${s.max}\n🔄 Refill: ${s.refill ? "Ya" : "Tidak"}\n\n`;
  });
  const keyboard = items.map(s => [{ text: `🛒 Order ${s.id}`, callback_data: `order_${s.id}` }]);
  const nav = [];
  if (page > 0) nav.push({ text: "⬅️ Prev", callback_data: `page_${encodeURIComponent(category)}_${page - 1}` });
  if (start + PAGE_SIZE < services.length) nav.push({ text: "Next ➡️", callback_data: `page_${encodeURIComponent(category)}_${page + 1}` });
  if (nav.length) keyboard.push(nav);
  keyboard.push([{ text: "⬅️ Back", callback_data: `back_cat_${encodeURIComponent(category.split(" ")[0])}` }]);
  if (msgId) {
    return bot.editMessageText(teks, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }).catch(async () => {
      await bot.sendMessage(chatId, teks, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }).catch(()=>{});
    });
  } else {
    return bot.sendMessage(chatId, teks, { parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } }).catch(()=>{});
  }
}
// ======= Entry points =======
bot.onText(/\/start(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  users.add(chatId);
  persistUsers();
  const param = (match && match[1] || "").trim();
  if (!referrals[chatId]) referrals[chatId] = { invitedBy: null, points: 0, invites: [] };
  if (param.startsWith("ref_")) {
    const inviterId = param.replace("ref_", "");
    if (inviterId !== String(chatId)) {
      referrals[chatId].invitedBy = inviterId;
      if (!referrals[inviterId]) referrals[inviterId] = { invitedBy: null, points: 0, invites: [] };
      referrals[inviterId].points = (referrals[inviterId].points || 0) + 1;
      referrals[inviterId].invites = referrals[inviterId].invites || [];
      referrals[inviterId].invites.push(chatId);
      bot.sendMessage(inviterId, `🎉 Kamu berhasil mengundang ${msg.from.first_name}!\nPoin kamu: ${referrals[inviterId].points}`).catch(()=>{});
      saveReferrals();
    }
  }
  showMainMenu(chatId);
});
// keep users tracked on any message
bot.on("message", (msg) => {
  const chatId = msg.chat.id;
  if (chatId) {
    users.add(chatId);
    persistUsers();
  }
});
// ======= Callback handler (all inline buttons) =======
bot.on("callback_query", async (cq) => {
  const chatId = cq.message.chat.id;
  const msgId = cq.message.message_id;
  const data = cq.data;
  const fromUsername = cq.from.username || "";
  bot.answerCallbackQuery(cq.id).catch(()=>{});
  if (data === "menu_layanan") return showCategories(chatId, 0, msgId);
  if (data === "menu_saldo") {
    return bot.editMessageText(`💰 Saldo kamu: Rp${getBalance(chatId)}`, { chat_id: chatId, message_id: msgId, reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] } }).catch(()=>{});
  }
  if (data === "menu_referral") {
    const link = makeReferralLink(chatId);
    return bot.editMessageText(`🔗 Referral link kamu:\n\`${link}\`\n\nBagikan untuk dapat poin.`, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] } }).catch(()=>{});
  }
  if (data === "menu_history") return showHistory(chatId, msgId);
  if (data === "menu_profile") {
    return showUserInfo(chatId, cq.from);
  }
  if (data === "menu_admin") {
    return bot.editMessageText("🔐 Admin login: tekan tombol di bawah untuk memeriksa akses (username Telegram harus cocok dengan daftar GitHub).", {
      chat_id: chatId,
      message_id: msgId,
      reply_markup: { inline_keyboard: [[{ text: "🔎 Cek Akses Admin", callback_data: "admin_check_access" }], [{ text: "⬅️ Back", callback_data: "back_main" }]] }
    }).catch(()=>{});
  }
  if (data === "back_main") return showMainMenu(chatId, msgId);
  if (data.startsWith("catpage_")) {
    const page = parseInt(data.split("_")[1]) || 0;
    return showCategories(chatId, page, msgId);
  }
  if (data.startsWith("cat_")) {
    const platform = data.slice(4);
    return showSubCategories(chatId, platform, 0, msgId);
  }
  if (data.startsWith("subcatpage_")) {
    const parts = data.split("_");
    const encPlatform = parts[1];
    const page = parseInt(parts[2]) || 0;
    const platform = decodeURIComponent(encPlatform);
    return showSubCategories(chatId, platform, page, msgId);
  }
  if (data.startsWith("subcat_")) {
    const encoded = data.slice(7);
    const category = decodeURIComponent(encoded);
    return showServicesPage(chatId, category, 0, msgId);
  }
  if (data.startsWith("page_")) {
    const parts = data.split("_");
    const encodedCategory = parts[1];
    const page = parseInt(parts[2]) || 0;
    const category = decodeURIComponent(encodedCategory);
    return showServicesPage(chatId, category, page, msgId);
  }
  if (data.startsWith("back_cat_")) {
    const plat = decodeURIComponent(data.split("_")[2] || "");
    return showSubCategories(chatId, plat, 0, msgId);
  }
  if (data === "back_platform") return showCategories(chatId, 0, msgId);
  if (data.startsWith("order_")) {
    const sid = parseInt(data.split("_")[1]);
    const services = await fetchServices();
    const service = services.find(s => Number(s.id) === Number(sid));
    if (!service) return bot.sendMessage(chatId, "⚠️ Layanan tidak ditemukan.").catch(()=>{});
    pendingOrders[chatId] = { step: "target", service, processing: false, confirmMessageId: null };
    return bot.sendMessage(chatId, `🛒 Order *${escapeMarkdown(service.name)}*\n\nMasukkan target (username/link):`, { parse_mode: "Markdown" }).catch(()=>{});
  }
 if (data === "admin_check_access") {
  const allowed = await fetchGithubAdmins();
  if (!Array.isArray(allowed) || !allowed.length) {
    return bot.editMessageText(
      "❌ Admin list not available (GitHub file unreachable).",
      { chat_id: chatId, message_id: msgId }
    ).catch(() => {});
  }

  const telegramUsername = cq.from.username || "";
  if (!allowed.includes(telegramUsername)) {
    return bot.editMessageText(
      "❌ Kamu tidak punya akses admin.",
      { chat_id: chatId, message_id: msgId }
    ).catch(() => {});
  }

  // 🆕 Tambah dua fitur baru di sini
  const kb = [
    [{ text: "📋 Daftar User", callback_data: "admin_list_users" }],
    [{ text: "💰 Topup Saldo", callback_data: "admin_topup" }],
    [{ text: "💵 Cek Saldo", callback_data: "admin_check_balance" }], // ✅ Baru
    [{ text: "💾 Backup Otomatis", callback_data: "admin_backup_auto" }], // ✅ Baru
    [{ text: "📣 Broadcast", callback_data: "admin_broadcast" }],
    [{ text: "⬅️ Back", callback_data: "back_main" }],
  ];

  return bot.editMessageText(
    "👑 Selamat datang Admin. Pilih aksi:",
    { chat_id: chatId, message_id: msgId, reply_markup: { inline_keyboard: kb } }
  ).catch(() => {});
}

async function fetchAdminBalance() {
  const payload = {
    api_id: API_ID,
    api_key: API_KEY
  };

  console.log("fetchAdminBalance: Sending API request with payload:", payload);

  try {
    const resp = await axios.post("https://fayupedia.id/api/balance", payload, { timeout: 15000 });
    console.log("fetchAdminBalance: API response:", {
      statusCode: resp.status,
      data: resp.data
    });

    const data = resp.data;

    if (data.status === true && typeof data.balance === "number") {
      return { success: true, balance: data.balance };
    }

    return { success: false, message: data.msg || "Respon tidak valid." };
  } catch (e) {
    console.error("fetchAdminBalance error:", {
      statusCode: e.response ? e.response.status : null,
      data: e.response ? e.response.data : null,
      message: e.message || e
    });
    return { success: false, message: "Gagal menghubungi server API." };
  }
}

if (data === "admin_check_balance") {
  await bot.editMessageText("💵 Mengecek saldo akun admin...", {
    chat_id: chatId,
    message_id: msgId
  }).catch(() => {});

  const result = await fetchAdminBalance();

  if (result.success) {
    const formatted = result.balance.toLocaleString("id-ID");
    return bot.editMessageText(
      `💰 *Saldo Akun Admin:*\nRp *${formatted}*`,
      {
        chat_id: chatId,
        message_id: msgId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🔄 Refresh", callback_data: "admin_check_balance" }],
            [{ text: "⬅️ Kembali", callback_data: "admin_check_access" }]
          ]
        }
      }
    ).catch(() => {});
  } else {
    return bot.editMessageText(
      `❌ Gagal mengambil saldo admin.\n🧾 Pesan: *${result.message}*`,
      {
        chat_id: chatId,
        message_id: msgId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🔄 Coba Lagi", callback_data: "admin_check_balance" }],
            [{ text: "⬅️ Kembali", callback_data: "admin_check_access" }]
          ]
        }
      }
    ).catch(() => {});
  }
}

async function uploadToGithub(filePath, name) {
  const GITHUB_TOKEN = "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"; // ❗ Ganti token kamu di sini, atau simpan di process.env
  const REPO_OWNER = "DaffaHeroik";
  const REPO_NAME = "herosmmbot";
  const BRANCH = "main";

  const now = new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Makassar",
    hour12: false
  });

  const safeNow = now.replace(/[/,: ]/g, "-");
  const FILE_NAME = `${name}-${safeNow}.zip`;

  console.log(`uploadToGithub: Uploading ${FILE_NAME}...`);

  const content = fs.readFileSync(filePath, { encoding: "base64" });

  await axios.put(
    `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${FILE_NAME}`,
    {
      message: `Backup otomatis - ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Makassar" })}`,
      content,
      branch: BRANCH
    },
    {
      headers: {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        "User-Agent": "backup-script",
        Accept: "application/vnd.github.v3+json"
      }
    }
  );

  console.log("uploadToGithub: Upload sukses!");
}

if (data === "admin_backup_auto") {
  await bot.editMessageText("💾 Membuat cadangan otomatis, mohon tunggu sebentar...", {
    chat_id: chatId,
    message_id: msgId
  }).catch(() => {});

  try {
    const name = "HeroSMMBOTSC";


    // 🔄 Tunggu sebentar agar tampil efek progres
    await new Promise(res => setTimeout(res, 1000));

    // 🗜️ Buat file ZIP project (kecuali beberapa folder)
    const ls = execSync("ls")
      .toString()
      .split("\n")
      .filter(pe =>
        pe &&
        pe !== "node_modules" &&
        pe !== "session" &&
        pe !== "package-lock.json" &&
        pe !== "yarn.lock"
      );

    const zipName = `${name}.zip`;
    execSync(`zip -r ${zipName} ${ls.join(" ")}`);
    console.log(`Created ZIP file: ${zipName}`);

    // 🚀 Upload ke GitHub
    await uploadToGithub(`./${zipName}`, name);

    // 📤 Kirim file ZIP ke admin di Telegram
    await bot.sendDocument(chatId, fs.readFileSync(`./${zipName}`), {
      filename: `${name}.zip`,
      caption: "✅ Backup selesai dan sudah diupload ke GitHub."
    });

    // 🧹 Hapus file ZIP setelah dikirim
    execSync(`rm -rf ${zipName}`);

    await bot.sendMessage(chatId, "📦 File backup juga sudah dihapus dari server untuk keamanan.").catch(() => {});

  } catch (err) {
    console.error("Backup error:", err);
    await bot.sendMessage(chatId, `❌ Gagal membuat backup otomatis.\nError: ${err.message}`).catch(() => {});
  }
}

  if (data === "admin_list_users") {
    const arr = Array.from(users);
    let teks = `👥 Daftar Users (${arr.length}):\n\n`;
    const list = arr.slice(0, 200);
    list.forEach(u => {
      teks += `• ${u}\n`;
    });
    if (arr.length > list.length) teks += `\n...dan ${arr.length - list.length} user lainnya.`;
    return bot.sendMessage(chatId, teks).catch(()=>{});
  }
  if (data === "admin_topup") {
    adminPending[chatId] = { action: "topup" };
    return bot.sendMessage(chatId, "📥 Masukkan perintah topup dalam format:\n`userId jumlah`\nContoh: `123456789 50000`", { parse_mode: "Markdown" }).catch(()=>{});
  }
  if (data === "admin_broadcast") {
    adminPending[chatId] = { action: "broadcast" };
    return bot.sendMessage(chatId, "📣 Kirim pesan yang ingin dibroadcast ke semua user (masukkan di chat ini):").catch(()=>{});
  }
});
// ======= Message handler (order inputs, admin inputs, simple commands) =======
bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const text = (msg.text || "").trim();
  if (!text) return;
  users.add(chatId);
  persistUsers();
  if (adminPending[chatId]) {
    const info = adminPending[chatId];
    if (info.action === "broadcast") {
      const allowed = await fetchGithubAdmins();
      const username = msg.from.username || "";
      if (!allowed.includes(username)) {
        adminPending[chatId] = null;
        return bot.sendMessage(chatId, "❌ Kamu bukan admin. Broadcast dibatalkan.").catch(()=>{});
      }
      const targets = Array.from(users);
      bot.sendMessage(chatId, `🚀 Mulai broadcast ke ${targets.length} user...`).catch(()=>{});
      for (const id of targets) {
        try { await bot.sendMessage(id, `📢 Broadcast dari Admin:\n\n${text}`); } catch(e){ /* ignore per-user errors */ }
      }
      adminPending[chatId] = null;
      return bot.sendMessage(chatId, "✅ Broadcast selesai.").catch(()=>{});
    }
    if (info.action === "topup") {
      const parts = text.split(/\s+/);
      if (parts.length < 2) return bot.sendMessage(chatId, "⚠️ Format salah. Gunakan: `userId jumlah`", { parse_mode: "Markdown" }).catch(()=>{});
      const uid = parts[0];
      const amt = parseInt(parts[1]);
      if (isNaN(amt)) return bot.sendMessage(chatId, "⚠️ Jumlah tidak valid.").catch(()=>{});
      try {
        await addBalance(uid, amt, chatId);
        adminPending[chatId] = null;
        await bot.sendMessage(chatId, `✅ Saldo user ${uid} ditambah Rp${amt}. Saldo sekarang: Rp${getBalance(uid)}`).catch(()=>{});
      } catch (e) {
        console.error("Topup error:", e.message || e);
        await bot.sendMessage(chatId, `❌ Gagal menambah saldo: ${e.message || 'error'}`).catch(()=>{});
      }
      return;
    }
  }
  const po = pendingOrders[chatId];
  if (po && po.step) {
    if (po.step === "target") {
      po.target = text;
      po.step = "quantity";
      return bot.sendMessage(chatId, "📌 Masukkan jumlah order (quantity):").catch(()=>{});
    }
    if (po.step === "quantity") {
      const qty = parseInt(text);
      if (isNaN(qty) || qty <= 0) return bot.sendMessage(chatId, "⚠️ Quantity tidak valid. Masukkan angka.").catch(()=>{});
      if (po.service.min && qty < po.service.min) return bot.sendMessage(chatId, `⚠️ Quantity minimal ${po.service.min}`).catch(()=>{});
      if (po.service.max && qty > po.service.max) return bot.sendMessage(chatId, `⚠️ Quantity maksimal ${po.service.max}`).catch(()=>{});
      po.quantity = qty;
      po.step = "confirm";
      const est = ((Number(po.service.price) + PRICE_MARKUP) * po.quantity) / 1000;
      const teks = `⚡ *Konfirmasi Order*\n\n🆔 Service: *${po.service.id}* - ${escapeMarkdown(po.service.name)}\n🎯 Target: ${escapeMarkdown(po.target)}\n🔢 Quantity: ${po.quantity}\n💰 Total (estimasi): Rp${est}\n\nKetik *YES* untuk konfirmasi atau *NO* untuk batalkan.`;
      return bot.sendMessage(chatId, teks, { parse_mode: "Markdown" }).catch(()=>{});
    }
    if (po.step === "confirm") {
      if (text.toLowerCase() === "yes" || text.toLowerCase() === "y") {
        if (po.processing) return bot.sendMessage(chatId, "⏳ Order sedang diproses...").catch(()=>{});
        po.processing = true;
        const est = ((Number(po.service.price) + PRICE_MARKUP) * po.quantity) / 1000;
        const saldo = getBalance(chatId);
        if (saldo < est) {
          delete pendingOrders[chatId];
          return bot.sendMessage(chatId, `❌ Saldo tidak cukup.\nSaldo: Rp${saldo}\nButuh: Rp${est}`).catch(()=>{});
        }
        try {
          const payload = {
            api_id: API_ID,
            api_key: API_KEY,
            service: po.service.id,
            target: po.target,
            quantity: po.quantity
          };
          console.log("Order API: Sending request with payload:", payload);
          const resp = await axios.post("https://fayupedia.id/api/order", payload, { timeout: 20000 });
          console.log("Order API: Response:", {
            statusCode: resp.status,
            data: resp.data
          });
          const d = resp.data || {};
          if (d.status && (d.order || d.order_id)) {
            const orderId = String(d.order || d.order_id); // Handle both order and order_id
            try {
              await addBalance(chatId, -est, chatId);
              const orderSaved = await addOrder(chatId, {
                orderId,
                serviceId: po.service.id,
                target: po.target,
                quantity: po.quantity,
                price: est,
                timestamp: Date.now()
              }, chatId);
              if (orderSaved) {
                await bot.sendMessage(chatId, `✅ Order berhasil!\nOrder ID: ${orderId}\nSaldo sisa: Rp${getBalance(chatId)}`).catch(()=>{});
              } else {
                await bot.sendMessage(chatId, `❌ Order berhasil di API tetapi gagal disimpan di database: ID order tidak valid`).catch(()=>{});
              }
            } catch (e) {
              console.error("Order processing error:", e.message || e);
              await bot.sendMessage(chatId, `❌ Gagal menyimpan order atau saldo: ${e.message || 'error'}`).catch(()=>{});
            }
          } else {
            console.warn("Order API response invalid:", d);
            await bot.sendMessage(chatId, `❌ Order gagal: ${d.msg || JSON.stringify(d)}`).catch(()=>{});
          }
        } catch (e) {
          console.error("Order API error:", {
            statusCode: e.response ? e.response.status : null,
            data: e.response ? e.response.data : null,
            message: e.message || e
          });
          await bot.sendMessage(chatId, `❌ Gagal membuat order: ${e.response?.data?.message || e.message || 'error'}`).catch(()=>{});
        }
        delete pendingOrders[chatId];
        return;
      } else {
        delete pendingOrders[chatId];
        return bot.sendMessage(chatId, "❌ Order dibatalkan.").catch(()=>{});
      }
    }
  }
  if (text.toLowerCase() === "hai") return bot.sendMessage(chatId, "Halo! 👋 Saya bot Telegram yang selalu online 🚀").catch(()=>{});
  if (text.toLowerCase() === "ping") return bot.sendMessage(chatId, "Pong! ✅").catch(()=>{});
  if (text === "/admin") {
    const fromUsername = msg.from.username || "";
    const allowed = await fetchGithubAdmins();
    if (!allowed.includes(fromUsername)) return bot.sendMessage(chatId, "❌ Kamu bukan admin.").catch(()=>{});
    const kb = [
      [{ text: "📋 Daftar User", callback_data: "admin_list_users" }],
      [{ text: "💰 Topup Saldo", callback_data: "admin_topup" }],
      [{ text: "📣 Broadcast", callback_data: "admin_broadcast" }],
      [{ text: "⬅️ Back", callback_data: "back_main" }],
    ];
    return bot.sendMessage(chatId, "👑 Admin Panel:", { reply_markup: { inline_keyboard: kb } }).catch(()=>{});
  }
});
// graceful save on exit
process.on('SIGINT', async () => { try { saveReferrals(); persistUsers(); await saveBalancesToGithub(); await saveOrdersToGithub(); } catch(e){} process.exit(); });
process.on('SIGTERM', async () => { try { saveReferrals(); persistUsers(); await saveBalancesToGithub(); await saveOrdersToGithub(); } catch(e){} process.exit(); });
// Init balances and orders before running
(async () => {
  await initBalances();
  await initOrders();
  console.log("Bot is running...");
})();