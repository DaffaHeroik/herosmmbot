// tokengrab.js
// npm i puppeteer axios dotenv
const fs = require("fs");
const path = require("path");
const puppeteer = require("puppeteer");
const axios = require("axios");
if (fs.existsSync(path.join(__dirname, ".env"))) require("dotenv").config();

/*const EMAIL = "daffaheroik" ;
const PASSWORD = "T@hbZPwvfSu@6Ur";*/

const EMAIL = process.env.TRIFLAZZ_EMAIL || "daffaheroik";
const PASSWORD = process.env.TRIFLAZZ_PASS || "T@hbZPwvfSu@6Ur";
const HEADLESS = (process.env.HEADLESS || "false").toLowerCase() === "true"; // default false (manual)
const USE_2CAPTCHA = (process.env.USE_2CAPTCHA || "false").toLowerCase() === "true";
const TWO_CAPTCHA_APIKEY = process.env.TWO_CAPTCHA_APIKEY || "6a1df8205c1665901a16bbd42eea3d59";
const LOGIN_URL = "https://triflazz.com/login";
const DASHBOARD_URL = "https://triflazz.com/pemesanan/otp";
const SESSION_FILE = path.join(__dirname, "session.json");
const NAV_TIMEOUT = 30000;
// tokengrab.js
// npm i puppeteer axios dotenv

if (!EMAIL || !PASSWORD) {
  console.error("Set TRIFLAZZ_EMAIL and TRIFLAZZ_PASS in .env file.");
  process.exit(2);
}

async function solveRecaptchaBy2Captcha(page, siteKey, pageUrl, apiKey) {
  try {
    console.log("🔁 2Captcha: requesting solution...");
    const req = await axios.get("http://2captcha.com/in.php", {
      params: {
        key: apiKey,
        method: "userrecaptcha",
        googlekey: siteKey,
        pageurl: pageUrl,
        json: 1,
      },
      timeout: 15000
    });
    if (!req.data || req.data.status !== 1) throw new Error("2Captcha error: " + JSON.stringify(req.data));
    const requestId = req.data.request;
    for (let i = 0; i < 40; i++) {
      await new Promise(r => setTimeout(r, 5000));
      const res = await axios.get("http://2captcha.com/res.php", {
        params: { key: apiKey, action: "get", id: requestId, json: 1 },
        timeout: 15000
      });
      if (res.data && res.data.status === 1) {
        console.log("✅ 2Captcha solved.");
        return res.data.request;
      }
      if (res.data.request === "CAPCHA_NOT_READY") continue;
    }
    throw new Error("2Captcha timeout");
  } catch (e) {
    throw e;
  }
}

async function grabCookies() {
  console.log(`🔐 Starting Puppeteer (headless=${HEADLESS})...`);
  const browser = await puppeteer.launch({
    headless: HEADLESS,
    args: ["--no-sandbox", "--disable-setuid-sandbox"],
  });
  const page = await browser.newPage();
  await page.setUserAgent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/141 Safari/537.36");

  try {
    await page.goto(LOGIN_URL, { waitUntil: "networkidle2", timeout: NAV_TIMEOUT });

    const emailSel = await page.$('input[name="email"]') ? 'input[name="email"]' : '#email';
    const passSel = await page.$('input[name="password"]') ? 'input[name="password"]' : '#password';

    await page.type(emailSel, EMAIL, { delay: 50 });
    await page.type(passSel, PASSWORD, { delay: 50 });

    const submitBtn = await page.$('button[type="submit"], input[type="submit"]');
    if (submitBtn) await submitBtn.click();

    try {
      await page.waitForNavigation({ waitUntil: "networkidle2", timeout: NAV_TIMEOUT });
    } catch {}

    await page.goto(DASHBOARD_URL, { waitUntil: "networkidle2", timeout: NAV_TIMEOUT });

    const cookies = await page.cookies();
    const cookieString = cookies.map(c => `${c.name}=${c.value}`).join("; ");
    const payload = { token: cookieString, fetchedAt: new Date().toISOString() };
    fs.writeFileSync(SESSION_FILE, JSON.stringify(payload, null, 2), "utf8");

    console.log("✅ Session saved to", SESSION_FILE);

    // kirim hasil ke stdout supaya bisa dibaca proses induk (main.js)
    console.log(JSON.stringify(payload));

    await browser.close();
    process.exit(0);
  } catch (err) {
    console.error("ERROR during token grab:", err.message);
    await browser.close();
    process.exit(3);
  }
}

// jalankan otomatis kalau file ini dijalankan langsung
if (require.main === module) {
  grabCookies();
}

// export kalau mau diimpor manual
module.exports = { grabCookies };
