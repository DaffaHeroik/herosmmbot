/**
 * login_extract_cookies_full.js
 *
 * Usage:
 * 1) npm install axios form-data tough-cookie axios-cookiejar-support
 * 2) Edit konstanta USERNAME, PASSWORD, TWO_CAPTCHA_API_KEY sesuai kebutuhan
 * 3) node login_extract_cookies_full.js
 *
 * NOTE: Jangan gunakan untuk aktivitas ilegal. Hanya untuk edukasi/otomatisasi yang sah.
 */

const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs').promises;
const path = require('path');

const { CookieJar } = require('tough-cookie');
const { wrapper } = require('axios-cookiejar-support');

const LOGIN_URL = 'https://triflazz.com/auth/login';

// ---- CONFIG ----
const USERNAME = 'daffaheroik';
const PASSWORD = 'T@hbZPwvfSu@6Ur';
const TWO_CAPTCHA_API_KEY = '6a1df8205c1665901a16bbd42eea3d59'; // jika kosong, captcha tidak akan diselesaikan otomatis
// ----------------

/**
 * Solve reCAPTCHA (v2) via 2captcha (optional).
 * Returns token string or null on failure.
 */
async function solveCaptcha2captcha(siteKey, pageUrl) {
  if (!TWO_CAPTCHA_API_KEY) {
    console.log('TWO_CAPTCHA_API_KEY kosong — melewati solve captcha.');
    return null;
  }
  try {
    // submit captcha
    const submitResp = await axios.get('http://2captcha.com/in.php', {
      params: {
        key: TWO_CAPTCHA_API_KEY,
        method: 'userrecaptcha',
        googlekey: siteKey,
        pageurl: pageUrl,
        json: 1
      },
      timeout: 30000
    });
    if (!submitResp.data || submitResp.data.status !== 1) {
      console.error('Gagal submit captcha ke 2captcha:', submitResp.data);
      return null;
    }
    const requestId = submitResp.data.request;
    console.log('2captcha request id:', requestId);

    // polling hasil
    for (let i = 0; i < 30; i++) { // ~up to 150s
      await new Promise((r) => setTimeout(r, 5000));
      const res = await axios.get('http://2captcha.com/res.php', {
        params: {
          key: TWO_CAPTCHA_API_KEY,
          action: 'get',
          id: requestId,
          json: 1
        },
        timeout: 30000
      });

      if (res.data && res.data.status === 1) {
        console.log('Captcha solved by 2captcha.');
        return res.data.request;
      }

      if (res.data && res.data.request === 'CAPCHA_NOT_READY') {
        console.log('Captcha not ready yet...');
        continue;
      }

      console.log('2captcha response:', res.data);
      // fallback break if unexpected
    }

    console.error('Timeout menunggu 2captcha.');
    return null;
  } catch (err) {
    console.error('Error solveCaptcha2captcha:', err.message || err);
    return null;
  }
}

/**
 * Extract candidate cookie values from raw HTML/JS using regex heuristics.
 * Tries multiple patterns for common placements.
 */
function extractCookiesFromHtml(html) {
  const out = {
    _gcl_au: '',
    cookie_token: ''
  };

  if (!html) return out;

  // _gcl_au: search patterns like: _gcl_au=1.1.1084...  OR "_gcl_au":"1.1...." OR var _gcl_au = "1.1..."
  const gclPatterns = [
    /_gcl_au\s*[:=]\s*["']([^"']+)["']/i,
    /_gcl_au=([^;'"<\s]+)/i,
    /"_gcl_au"\s*:\s*"([^"]+)"/i
  ];
  for (const r of gclPatterns) {
    const m = html.match(r);
    if (m) {
      out._gcl_au = m[1];
      break;
    }
  }

  // cookie_token: many situs menyimpan token seperti cookie_token = "edd7..." OR "cookie_token":"..."
  const tokenPatterns = [
    /cookie_token\s*[:=]\s*["']([a-z0-9\-_]{8,})["']/i,
    /"cookie_token"\s*:\s*"([a-z0-9\-_]{8,})"/i,
    /cookie_token\s*=\s*([a-z0-9\-_]{8,});/i
  ];
  for (const r of tokenPatterns) {
    const m = html.match(r);
    if (m) {
      out.cookie_token = m[1];
      break;
    }
  }

  return out;
}

/**
 * Build COOKIE_STRING in order: _gcl_au, PHPSESSID, cookie_token
 * Values will be empty string if not found (keperluan konsistensi).
 */
function buildCookieString(values) {
  const parts = [
    `_gcl_au=${values._gcl_au || ''}`,
    `PHPSESSID=${values.PHPSESSID || ''}`,
    `cookie_token=${values.cookie_token || ''}`
  ];
  return parts.join('; ');
}

async function main() {
  const jar = new CookieJar();
  const client = wrapper(axios.create({
    jar,
    withCredentials: true,
    headers: {
      'User-Agent': 'Mozilla/5.0 (Node.js) axios'
    },
    // allow large timeouts in case 2captcha used
    timeout: 120000
  }));

  try {
    // 1) Ambil halaman login
    console.log('Mengambil halaman login...');
    const pageResp = await client.get(LOGIN_URL, { responseType: 'text' });
    const pageHtml = pageResp.data || '';

    // 2) coba temukan sitekey reCAPTCHA (jika ada)
    const siteKeyMatch = pageHtml.match(/data-sitekey=["']([^"']+)["']/i);
    const siteKey = siteKeyMatch ? siteKeyMatch[1] : null;
    if (siteKey) console.log('Sitekey reCAPTCHA ditemukan:', siteKey);
    else console.log('Sitekey reCAPTCHA tidak ditemukan di HTML.');

    // 3) coba ekstrak _gcl_au dan cookie_token dari HTML (client-side set)
    const extractedFromHTML = extractCookiesFromHtml(pageHtml);
    console.log('Hasil ekstraksi dari HTML (sementara):', extractedFromHTML);

    // 4) Jika perlu, selesaikan captcha via 2captcha
    let captchaToken = null;
    if (siteKey) {
      captchaToken = await solveCaptcha2captcha(siteKey, LOGIN_URL);
      if (!captchaToken) {
        console.log('Captcha tidak diselesaikan, melanjutkan tanpa token (kemungkinan login akan gagal).');
      } else {
        console.log('Captcha token diterima (panjang):', captchaToken.length);
      }
    }

    // 5) Siapkan form data login
    const form = new FormData();
    form.append('user', USERNAME);
    form.append('pass', PASSWORD);
    // jika server pakai field g-recaptcha-response
    if (captchaToken) form.append('g-recaptcha-response', captchaToken);
    // btn name "login"
    form.append('login', 'Masuk');

    // 6) POST login (ikuti redirect supaya cookie jar menerima cookie dari redirect)
    console.log('Mengirim request login...');
    const postResp = await client.post(LOGIN_URL, form, {
      headers: {
        ...form.getHeaders()
      },
      maxRedirects: 10 // izinkan mengikuti redirect agar cookie jar mendapat cookie
    });

    // 7) Setelah login, ambil semua cookie dari jar untuk domain target
    const cookies = await jar.getCookies(LOGIN_URL);
    // ubah jadi map key->value
    const cookieMap = {};
    for (const c of cookies) {
      cookieMap[c.key] = c.value;
    }
    console.log('Cookies dari jar:', cookieMap);

    // 8) Kalau beberapa cookie belum ada (misal _gcl_au atau cookie_token), gunakan hasil parsing HTML
    const finalCookies = {
      _gcl_au: cookieMap._gcl_au || extractedFromHTML._gcl_au || '',
      PHPSESSID: cookieMap.PHPSESSID || '',
      cookie_token: cookieMap.cookie_token || extractedFromHTML.cookie_token || ''
    };

    // 9) Sebagai lapisan tambahan: kadang situs men-set cookie via body response setelah POST,
    //    jadi coba cari pola di body respons POST jika kosong
    const postBody = (postResp && postResp.data) ? String(postResp.data) : '';
    if (!finalCookies._gcl_au) {
      const tryHtml = extractCookiesFromHtml(postBody);
      if (tryHtml._gcl_au) finalCookies._gcl_au = tryHtml._gcl_au;
    }
    if (!finalCookies.cookie_token) {
      const tryHtml = extractCookiesFromHtml(postBody);
      if (tryHtml.cookie_token) finalCookies.cookie_token = tryHtml.cookie_token;
    }

    // 10) susun COOKIE_STRING dan simpan JSON
    const COOKIE_STRING = buildCookieString(finalCookies);
    const out = {
      COOKIE_STRING,
      cookies: finalCookies,
      raw_jar: cookieMap,
      extracted_from_html: extractedFromHTML,
      extracted_at: new Date().toISOString()
    };

    const outPath = path.resolve(__dirname, 'cookies.json');
    await fs.writeFile(outPath, JSON.stringify(out, null, 2), 'utf8');

    console.log('Selesai. COOKIE_STRING:');
    console.log(COOKIE_STRING);
    console.log('Hasil disimpan di:', outPath);

    // contoh: gunakan COOKIE_STRING langsung untuk request berikutnya
    // const protected = await client.get('https://triflazz.com/some/protected/page', {
    //   headers: { Cookie: COOKIE_STRING, 'User-Agent': 'Mozilla/5.0 (Node.js) axios' }
    // });
    // console.log('Protected status', protected.status);

  } catch (err) {
    console.error('Terjadi error:', err && err.message ? err.message : err);
    if (err.response) {
      console.error('Response status:', err.response.status);
      // print sebagian body utk debug
      try {
        const txt = typeof err.response.data === 'string' ? err.response.data : JSON.stringify(err.response.data);
        console.error('Response body (potongan):', txt.slice(0, 800));
      } catch (e) { /* ignore */ }
    }
    process.exitCode = 1;
  }
}

if (require.main === module) {
  // Fungsi untuk menjalankan proses login & ekstraksi
  async function run() {
    console.log(`[${new Date().toLocaleString()}] Menjalankan login dan ekstraksi cookies...`);
    try {
      await main();
      console.log(`[${new Date().toLocaleString()}] Selesai ✅\n`);
    } catch (err) {
      console.error(`[${new Date().toLocaleString()}] Gagal menjalankan proses:`, err.message);
    }
  }

  // Jalankan pertama kali saat file dieksekusi
  run();

  // Ulangi setiap 20 jam (20 * 60 * 60 * 1000 = 72.000.000 ms)
  const interval = 20 * 60 * 60 * 1000;
  setInterval(run, interval);
}

