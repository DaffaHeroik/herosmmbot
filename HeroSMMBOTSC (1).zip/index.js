const { fork } = require("child_process");

console.log("🚀 Menjalankan 4 bot...");

const bots = [
  { name: "Bot1 SMM", file: "bot.js" },
  { name: "Bot2 GAME", file: "bot1.js" },
  { name: "Bot3 NOKOS", file: "botnokos.js" },
    { name: "Bot4 REkber", file: "bottest.js" },
    
];
// { name: "Program Extract Cookie", file: "login_extract_cookies.js" },

// Menyimpan proses yang sedang aktif
const processes = new Map();

// Fungsi untuk menjalankan bot
function startBot(bot) {
  console.log(`[${bot.name}] dijalankan.`);
  const child = fork(bot.file);

  // Simpan di map supaya bisa di-kill saat restart 24 jam
  processes.set(bot.name, child);

  // Restart otomatis jika bot mati / error
  child.on("exit", (code, signal) => {
    console.log(`[${bot.name}] mati (code: ${code}, signal: ${signal}), restart...`);
    startBot(bot);
  });
}

// Jalankan semua bot awal
bots.forEach(startBot);

// Fungsi restart semua bot setiap 24 jam
const restartAllBots = () => {
  console.log(`\n🕒 [${new Date().toLocaleString()}] Restart semua bot (24 jam)...\n`);

  for (const bot of bots) {
    const proc = processes.get(bot.name);
    if (proc) {
      console.log(`[${bot.name}] dimatikan untuk restart...`);
      proc.kill(); // akan trigger auto restart karena event 'exit'
    }
  }
};

// Setiap 24 jam (24 * 60 * 60 * 1000 = 86.400.000 ms)
const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
setInterval(restartAllBots, TWENTY_FOUR_HOURS);
