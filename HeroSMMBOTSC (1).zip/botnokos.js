// bot.js - Full SMM Panel Telegram Bot (referral + layanan + order + admin + broadcast + saldo + history)
// Requirements: npm i node-telegram-bot-api axios
const TelegramBot = require("node-telegram-bot-api");
const fs = require("fs");
const fetch = require('node-fetch'); // npm install node-fetch
const axios = require("axios");
const QRCode = require("qrcode");
const path = require("path"); 
const EventEmitter = require("events");
const { execSync } = require("child_process");
const SESSION_FILE = path.join(__dirname, "session.json");
// ====================== CONFIG ======================
const BOT_TOKEN = "8365438608:AAE_tf3V-EB1V89Sn52jk7Q6U0mgb6FVtJ4"; // token bot
const BOT_USERNAME = "heroikzre_nokosbot"; // username bot (untuk referral)
const API_ID = 115499;
const API_KEY = "1534tg-vmhgxu-1dbq0a-mnp2ji-zfr7xc";
// raw URL GitHub admins.json (array JSON) - sesuaikan jika perlu
const GITHUB_ADMINS_RAW_URL = "https://raw.githubusercontent.com/DaffaHeroik/herosmmbot/main/admins.json";


// GitHub config for balances and orders
const GITHUB_OWNER = "DaffaHeroik";
const GITHUB_REPO = "herosmmbot";
const GITHUB_BALANCES_PATH = "balances.json";
const GITHUB_ORDERS_PATH = "orderppob.json";
const GITHUB_TOKEN = "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"; // Ganti dengan GitHub Personal Access Token (PAT) Anda yang memiliki scope repo
const GITHUB_BALANCES_RAW_URL = `https://raw.githubusercontent.com/${GITHUB_OWNER}/${GITHUB_REPO}/main/${GITHUB_BALANCES_PATH}`;
const GITHUB_ORDERS_RAW_URL = `https://raw.githubusercontent.com/${GITHUB_OWNER}/${GITHUB_REPO}/main/${GITHUB_ORDERS_PATH}`;
// local DB files (referrals and users still local)
const REFERRAL_DB = "referral.json";
const USERS_DB = "users.json";
const SUBSCRIBERS_DB = "subscribers.json"; // New DB for subscribers
//AUTOBACKUP
let autoBackupEnabled = false; // status auto backup (ON/OFF)
let lastBackupTime = null; // waktu backup terakhir
let autoBackupInterval = null; // penyimpan interval timer
// pagination
const PAGE_SIZE = 5;
// OkeConnect H2H Config
const OKEC_MEMBER_ID = 'OK2296369';
const OKEC_PIN = '1328';
const OKEC_PASSWORD = 'qwerty123';
// price markup (Rp)
const PRICE_MARKUP = 0.25; // setiap produk dinaikkan 100
// ====================================================
const bot = new TelegramBot(BOT_TOKEN, { polling: true });
// ======= Helpers: load/save JSON (for local files) =======
function loadJson(path, def) {
  try {
    if (fs.existsSync(path)) return JSON.parse(fs.readFileSync(path));
  } catch (e) { console.error("loadJson error", e); }
  return def;
}
function saveJson(path, obj) {
  fs.writeFileSync(path, JSON.stringify(obj, null, 2));
}
// DB in memory
let referrals = loadJson(REFERRAL_DB, {}); // { chatId: { invitedBy, points, invites:[] } }
let users = new Set(loadJson(USERS_DB, [])); // store chat ids
let balances = {}; // in-memory, fetched/updated via GitHub
let orders = {}; // { chatId: [{ orderId, serviceId, target, quantity, price, timestamp }] }
let subscribers = loadJson(SUBSCRIBERS_DB, []); // New: array of { id: chatId, name: "Name" } for subscribers

function saveSubscribers() { saveJson(SUBSCRIBERS_DB, subscribers); }
function getCookieString() {
  const raw = fs.readFileSync(path.resolve(__dirname, 'cookies.json'), 'utf8');
  return JSON.parse(raw).COOKIE_STRING;
}
const COOKIE_STRING = getCookieString();
// persist helpers (local)
function persistUsers() { saveJson(USERS_DB, Array.from(users)); }
function saveReferrals() { saveJson(REFERRAL_DB, referrals); }
function saveSubscribers() { saveJson(SUBSCRIBERS_DB, subscribers); } // New: save subscribers
// GitHub balances functions (async)
async function initBalances() {
  try {
    const resp = await axios.get(GITHUB_BALANCES_RAW_URL, { timeout: 10000 });
    console.log("Raw balances.json content:", resp.data);
    if (Array.isArray(resp.data)) {
      console.warn("balances.json loaded as array, resetting to empty object");
      balances = {};
      await saveBalancesToGithub();
    } else if (typeof resp.data !== 'object' || resp.data === null) {
      console.warn("balances.json loaded as invalid type, resetting to empty object");
      balances = {};
      await saveBalancesToGithub();
    } else {
      balances = resp.data || {};
    }
    console.log("Balances loaded from GitHub:", balances);
  } catch (e) {
    console.error("initBalances error:", e.message || e);
    balances = {};
    await saveBalancesToGithub();
  }
}
// ===== User Data Handling =====
function getUser(chatId) {
  if (!referrals[chatId]) {
    referrals[chatId] = { invitedBy: null, poin: 0, invites: [] };
    saveReferrals();
  }
  return referrals[chatId];
}
function addPoin(chatId, jumlah) {
  const user = getUser(chatId);
  user.poin = (user.poin || 0) + jumlah;
  saveReferrals();
}
function reducePoin(chatId, jumlah) {
  const user = getUser(chatId);
  if (user.poin >= jumlah) {
    user.poin -= jumlah;
    saveReferrals();
    return true;
  }
  return false;
}
async function saveBalancesToGithub(chatId = null, retries = 3) {
  if (typeof balances !== 'object' || balances === null || Array.isArray(balances)) {
    console.warn("saveBalancesToGithub: balances is invalid, resetting to object");
    balances = {};
  }
  console.log("Saving balances to GitHub:", balances);
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const headers = {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
      };
      const getUrl = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${GITHUB_BALANCES_PATH}`;
      let sha;
      try {
        const getResp = await axios.get(getUrl, { headers, timeout: 10000 });
        sha = getResp.data.sha;
      } catch (e) {
        if (e.response && e.response.status !== 404) {
          throw e;
        }
      }
      const putUrl = getUrl;
      const data = {
        message: 'Update balances.json via bot (attempt ' + attempt + ')',
        content: Buffer.from(JSON.stringify(balances, null, 2)).toString('base64'),
        branch: 'main'
      };
      if (sha) data.sha = sha;
      const response = await axios.put(putUrl, data, { headers, timeout: 15000 });
      console.log("Balances saved to GitHub, commit SHA:", response.data.commit.sha);
      return;
    } catch (e) {
      console.error("saveBalancesToGithub error (attempt " + attempt + "):", e.response ? e.response.data : e.message || e);
      if (attempt === retries) {
        if (chatId) {
          await bot.sendMessage(chatId, `⚠️ Gagal menyimpan saldo ke GitHub: ${e.response?.data?.message || e.message || 'error'}`).catch(()=>{});
        }
        saveJson('balances_backup.json', balances);
        console.log("Saved balances to local backup: balances_backup.json");
        throw e;
      }
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
}
function getBalance(uid) { return balances[uid] || 0; }
async function addBalance(uid, amt, chatId = null) {
  const oldBalance = getBalance(uid);
  balances[uid] = oldBalance + amt;
  console.log(`Balance update for ${uid}: ${oldBalance} -> ${balances[uid]}`);
  await saveBalancesToGithub(chatId);
}
// GitHub orders functions (async)
async function initOrders() {
  try {
    const resp = await axios.get(GITHUB_ORDERS_RAW_URL, { timeout: 10000 });
    console.log("Raw orders.json content:", resp.data);
    if (Array.isArray(resp.data)) {
      console.warn("orders.json loaded as array, resetting to empty object");
      orders = {};
      await saveOrdersToGithub();
    } else if (typeof resp.data !== 'object' || resp.data === null) {
      console.warn("orders.json loaded as invalid type, resetting to empty object");
      orders = {};
      await saveOrdersToGithub();
    } else {
      orders = resp.data || {};
    }
    console.log("Orders loaded from GitHub:", orders);
  } catch (e) {
    console.error("initOrders error:", e.message || e);
    orders = {};
    await saveOrdersToGithub();
  }
}
async function saveOrdersToGithub(chatId = null, retries = 3) {
  if (typeof orders !== 'object' || orders === null || Array.isArray(orders)) {
    console.warn("saveOrdersToGithub: orders is invalid, resetting to object");
    orders = {};
  }
  console.log("Saving orders to GitHub:", orders);
  for (let attempt = 1; attempt <= retries; attempt++) {
    try {
      const headers = {
        Authorization: `Bearer ${GITHUB_TOKEN}`,
        Accept: 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
      };
      const getUrl = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${GITHUB_ORDERS_PATH}`;
      let sha;
      try {
        const getResp = await axios.get(getUrl, { headers, timeout: 10000 });
        sha = getResp.data.sha;
      } catch (e) {
        if (e.response && e.response.status !== 404) {
          throw e;
        }
      }
      const putUrl = getUrl;
      const data = {
        message: 'Update orders.json via bot (attempt ' + attempt + ')',
        content: Buffer.from(JSON.stringify(orders, null, 2)).toString('base64'),
        branch: 'main'
      };
      if (sha) data.sha = sha;
      const response = await axios.put(putUrl, data, { headers, timeout: 15000 });
      console.log("Orders saved to GitHub, commit SHA:", response.data.commit.sha);
      return;
    } catch (e) {
      console.error("saveOrdersToGithub error (attempt " + attempt + "):", e.response ? e.response.data : e.message || e);
      if (attempt === retries) {
        if (chatId) {
          await bot.sendMessage(chatId, `⚠️ Gagal menyimpan orders ke GitHub: ${e.response?.data?.message || e.message || 'error'}`).catch(()=>{});
        }
        saveJson('orders_backup.json', orders);
        console.log("Saved orders to local backup: orders_backup.json");
        throw e;
      }
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  }
}
async function addOrder(uid, orderDetails, chatId = null) {
  if (typeof orders !== 'object' || orders === null || Array.isArray(orders)) {
    console.error("addOrder: orders is invalid, resetting to object", orders);
    orders = {};
  }
  if (!orderDetails.orderId || typeof orderDetails.orderId !== 'string' || orderDetails.orderId === 'N/A') {
    console.error("addOrder: Invalid orderId", orderDetails.orderId);
    if (chatId) {
      await bot.sendMessage(chatId, `⚠️ Gagal menyimpan order: ID order tidak valid`).catch(()=>{});
    }
    return false;
  }
  if (!orders[uid]) orders[uid] = [];
  orders[uid].push(orderDetails);
  console.log(`Order added for ${uid}:`, orderDetails);
  await saveOrdersToGithub(chatId);
  return true;
}
// ======= Fetch Order Status =======
async function fetchOrderStatus(order) {
  if (!order || !order.refID || !order.product || !order.dest) {
    console.warn("fetchOrderStatus: Order tidak lengkap:", order);
    return { status: 'INVALID_DATA', raw: null };
  }
const OKEC_MEMBER_ID = "OK2296369";
const OKEC_PIN = "1328";
const OKEC_PASSWORD = "qwerty123";
  const params = {
    memberID: OKEC_MEMBER_ID,
    product: order.product,
    dest: order.dest,
    refID: order.refID,
    pin: OKEC_PIN,
    password: OKEC_PASSWORD,
    check: 1
  };
  try {
    const resp = await axios.get("https://h2h.okeconnect.com/trx", { params, timeout: 15000 });
    const responseText = String(resp.data).trim();
    console.log("fetchOrderStatus ←", responseText);
    // Deteksi status dari response
    let status = "UNKNOWN";
    if (/SUCCESS|SUKSES/i.test(responseText)) status = "SUCCESS";
    else if (/PENDING/i.test(responseText)) status = "PENDING";
    else if (/FAILED|GAGAL/i.test(responseText)) status = "FAILED";
    return { status, raw: responseText };
  } catch (e) {
    console.error("fetchOrderStatus ERROR:", e.response?.data || e.message);
    return { status: "ERROR", raw: null };
  }
}
// ======= Services cache (fetch from SMM panel) =======
let cacheServices = [];
let lastServicesFetch = 0;
const SERVICES_CACHE_TTL = 60 * 1000; // 60s
const userState = {};
async function fetchServices() {
  try {
    const now = Date.now();
    if (cacheServices.length && (now - lastServicesFetch) < SERVICES_CACHE_TTL) {
      return cacheServices;
    }
    const produkList = 'pulsa,sms_telepon,kuota_nasional,kuota_telkomsel,kuota_byu,kuota_indosat,kuota_tri,kuota_xl,kuota_smartfren,token_pln,saldo_gojek,ecommerce,digital,tagihan,finance,pascabayar,tagihan_pbb,pulsa_transfer';
    const url = `https://okeconnect.com/harga/json?id=905ccd028329b0a&produk=${produkList}`;
    const resp = await axios.get(url, { timeout: 15000 });
    if (resp.data && Array.isArray(resp.data)) {
      const activeServices = resp.data.filter(s => s.status === "1");
      cacheServices = activeServices;
      lastServicesFetch = now;
      // PERBAIKAN: Tambah logging kategori unik untuk debug
      console.log("Kategori unik dari API:", [...new Set(activeServices.map(s => s.kategori))]);
      return cacheServices;
    } else {
      console.warn("fetchServices: unexpected response", resp.data);
      return [];
    }
  } catch (e) {
    console.error("fetchServices error:", e.message || e);
    return [];
  }
}
function showUserInfo(chatId, user) {
  const userId = user.id;
  const firstName = user.first_name || "";
  const lastName = user.last_name || "";
  const fullName = (firstName + " " + lastName).trim();
  const username = user.username ? "@" + user.username : "(tidak ada username)";
  const teks =
    "🆔 *Informasi Pengguna*\n\n" +
    `👤 Nama: *${fullName}*\n` +
    `🔗 Username: ${username}\n` +
    `💡 User ID: \`${userId}\``;
  bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
}
// ======= Admin list from GitHub raw =======
async function fetchGithubAdmins() {
  try {
    const resp = await axios.get(GITHUB_ADMINS_RAW_URL, { timeout: 10000 });
    if (typeof resp.data === "string") {
      try {
     
        const parsed = JSON.parse(resp.data);
 console.log(resp.data)
        if (Array.isArray(parsed)) return parsed;
      } catch {
        return resp.data.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
      }
    } else if (Array.isArray(resp.data)) return resp.data;
    return [];
  } catch (e) {
    console.error("fetchGithubAdmins error:", e.message || e);
    return [];
  }
}
// ======= Utilities =======
function escapeMarkdown(text = "") {
  return String(text).replace(/([_*`\[])/g, "\\$1");
}
function makeReferralLink(chatId) {
  return `https://t.me/${BOT_USERNAME}?start=ref_${chatId}`;
}
// track flows
let pendingOrders = {}; // { chatId: { step, service, target, quantity, confirmMessageId, processing } }
let adminPending = {}; // { chatId: { action: 'broadcast'|'topup', temp: ... } }
// ======= Main menu (edit-capable) =======
async function showMainMenu(chatId, msgId = null) {
  const keyboard = [
    [{ text: "📂 Layanan", callback_data: "menu_layanan" }],
    [{ text: "💰 Saldo", callback_data: "menu_saldo" }],
    [{ text: "🧾 Referral", callback_data: "menu_referral" }],
    [{ text: "🎁 Tukar Poin", callback_data: "menu_tukar_poin" }], // <-- kategori baru
    [{ text: "📜 History Order", callback_data: "menu_history" }],
    [{ text: "👤 Profil", callback_data: "menu_profile" }],
 [{text: `${subscribers.some(s => s.id === chatId) ? 'Notifikasi ON' : 'Notifikasi OFF'}`,callback_data: "toggle_notif" }],
    [{ text: "👑 Admin (login)", callback_data: "menu_admin" }],
  ];

  const text = "👋 Selamat datang di *Heroikzre SMM Bot*!\n\nPilih menu di bawah:";

  if (msgId) {
    return bot.editMessageText(text, {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    }).catch(async () => {
      await bot.sendMessage(chatId, text, {
        parse_mode: "Markdown",
        reply_markup: { inline_keyboard: keyboard }
      }).catch(()=>{});
    });
  } else {
    return bot.sendMessage(chatId, text, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    }).catch(()=>{});
  }
}



// ======= Show History =======
async function showHistory(chatId, msgId = null) {
  const userOrders = orders[chatId] || [];

  if (!userOrders.length) {
    const text = "⚠️ Kamu belum memiliki riwayat transaksi.";
    if (msgId) {
      return bot.editMessageText(text, {
        chat_id: chatId,
        message_id: msgId,
        reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] }
      }).catch(()=>{});
    } else {
      return bot.sendMessage(chatId, text, {
        reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] }
      }).catch(()=>{});
    }
  }

  let teks = "📜 *Riwayat Pesanan Kamu*\n\n";

  for (const ord of userOrders) {
    // Ambil status terbaru dari endpoint OkeConnect
    const statusInfo = await fetchOrderStatus(ord);
    const status = statusInfo.status;

    teks += `🆔 OrderID: *${ord.orderId}*\n`;
    teks += `📦 Produk: ${ord.product}\n`;
    teks += `🎯 Tujuan: ${ord.dest}\n`;
    teks += `💸 Harga: Rp${Number(ord.price).toLocaleString('id-ID')}\n`;
    teks += `🕒 Waktu: ${new Date(ord.timestamp).toLocaleString('id-ID')}\n`;
    teks += `📊 Status: *${status}*\n`;
    teks += `━━━━━━━━━━━━━━━\n`;
  }

  if (msgId) {
    return bot.editMessageText(teks, {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] }
    }).catch(async () => {
      await bot.sendMessage(chatId, teks, { parse_mode: "Markdown" }).catch(()=>{});
    });
  } else {
    return bot.sendMessage(chatId, teks, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] }
    }).catch(()=>{});
  }
}


async function showDompetWallets(chatId, page = 0, msgId = null) {
  const services = await fetchServices();
  const dompet = services.filter(s => s.kategori === "DOMPET DIGITAL" && s.status === "1");

  // Ekstrak nama wallet dari keterangan (case-insensitive)
  const wallets = [...new Set(
    dompet.map(s => {
      const ket = (s.keterangan || '').toUpperCase();
      if (ket.includes("OVO")) return "OVO";
      if (ket.includes("DANA")) return "DANA";
      if (ket.includes("GOPAY") || ket.includes("GO-PAY")) return "GOPAY";
      if (ket.includes("SHOPEEPAY") || ket.includes("SHOPEE")) return "ShopeePay";
      if (ket.includes("LINKAJA") || ket.includes("LINK AJA")) return "LinkAja";
      if (ket.includes("GRABPAY") || ket.includes("GRAB")) return "GrabPay";
      if (ket.includes("ISAKU") || ket.includes("I-SAKU")) return "iSaku";
      if (ket.includes("DOKU")) return "Doku";
      if (ket.includes("ASTRA") || ket.includes("ASTRAPAY")) return "Astrapay";
      if (ket.includes("KASPRO")) return "Kaspro";
      return null;
    }).filter(Boolean)
  )].sort();

  const start = page * PAGE_SIZE;
  const items = wallets.slice(start, start + PAGE_SIZE);

  if (!items.length) {
    return bot.sendMessage(chatId, "Tidak ada dompet digital tersedia.").catch(() => {});
  }

  const keyboard = items.map(wallet => [{
    text: wallet,
    callback_data: `dompet_${encodeURIComponent(wallet)}`
  }]);

  const nav = [];
  if (page > 0) nav.push({ text: "Prev", callback_data: `dompetpage_${page - 1}` });
  if (start + PAGE_SIZE < wallets.length) nav.push({ text: "Next", callback_data: `dompetpage_${page + 1}` });

  if (nav.length) keyboard.push(nav);
  keyboard.push([{ text: "Kembali ke Kategori", callback_data: "back_categories" }]);

  const totalPages = Math.ceil(wallets.length / PAGE_SIZE);
  const text = `Pilih Dompet Digital (halaman ${page + 1} dari ${totalPages})`;

  const options = { chat_id: chatId, reply_markup: { inline_keyboard: keyboard } };
  if (msgId) {
    return bot.editMessageText(text, { ...options, message_id: msgId }).catch(() =>
      bot.sendMessage(chatId, text, options)
    );
  } else {
    return bot.sendMessage(chatId, text, options);
  }
}

async function showProductsByWallet(chatId, walletName, page = 0, msgId = null) {
  const services = await fetchServices();
  const products = services.filter(s =>
    s.kategori === "DOMPET DIGITAL" &&
    (s.keterangan.toUpperCase().includes(walletName.toUpperCase()) ||
     s.kode.toUpperCase().includes(walletName.toUpperCase()))
  );

  if (!products.length) {
    return bot.sendMessage(chatId, `Tidak ada top-up untuk *${escapeMarkdown(walletName)}*`, { parse_mode: "Markdown" });
  }

  // SORT DARI HARGA TERKECIL
  const sorted = products.sort((a, b) => {
    const hargaA = Math.ceil(Number(a.harga) * (1 + PRICE_MARKUP));
    const hargaB = Math.ceil(Number(b.harga) * (1 + PRICE_MARKUP));
    return hargaA - hargaB;
  });

  const start = page * PAGE_SIZE;
  const items = sorted.slice(start, start + PAGE_SIZE);

  let text = `TOPUP *${escapeMarkdown(walletName)}* (hal ${page + 1})\n\n`;
  items.forEach(s => {
    const hargaJual = Math.ceil(Number(s.harga) * (1 + PRICE_MARKUP));
    text += `*${s.kode}*\n${escapeMarkdown(s.keterangan)}\nHarga: *Rp ${hargaJual.toLocaleString('id-ID')}*\n\n`;
  });

  

  const keyboard = items.map(s => [{
    text: `Order ${s.kode}`,
    callback_data: `order_${s.kode}`
  }]);

  const nav = [];
  if (page > 0) nav.push({ text: "Prev", callback_data: `dompetprod_${encodeURIComponent(walletName)}_${page - 1}` });
  if (start + PAGE_SIZE < products.length) nav.push({ text: "Next", callback_data: `dompetprod_${encodeURIComponent(walletName)}_${page + 1}` });
  if (nav.length) keyboard.push(nav);
  keyboard.push([{ text: "Kembali ke Dompet", callback_data: "back_dompet_wallets" }]);

  const options = { chat_id: chatId, parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } };
  if (msgId) {
    return bot.editMessageText(text, { ...options, message_id: msgId }).catch(() =>
      bot.sendMessage(chatId, text, options)
    );
  } else {
    return bot.sendMessage(chatId, text, options);
  }
}



// ===== Tampilkan produk berdasarkan kategori (dengan pagination) =====
async function showProductsByCategory(chatId, category, page = 0, msgId = null) {
  const services = (await fetchServices()).filter(s => s.kategori === category);
  if (!services.length) {
    return bot.sendMessage(chatId, `Tidak ada produk di kategori *${escapeMarkdown(category)}*`, { parse_mode: "Markdown" }).catch(() => {});
  }
  const sorted = services.sort((a, b) => {
    const hargaA = Math.ceil(Number(a.harga) * (1 + PRICE_MARKUP));
    const hargaB = Math.ceil(Number(b.harga) * (1 + PRICE_MARKUP));
    return hargaA - hargaB;
  });
  const start = page * PAGE_SIZE;
  const items = sorted.slice(start, start + PAGE_SIZE);
  let text = `Kategori: *${escapeMarkdown(category)}* (halaman ${page + 1})\n\n`;
  items.forEach(s => {
    const hargaJual = Math.ceil(Number(s.harga) * (1 + PRICE_MARKUP));
    const hargaFormat = hargaJual.toLocaleString('id-ID'); // PERBAIKAN
    text += `*${s.kode}*\n${escapeMarkdown(s.keterangan)}\nHarga: *Rp ${hargaFormat}*\n\n`;
  });
  const totalPages = Math.ceil(services.length / PAGE_SIZE);
  if (totalPages > 1) {
    text += `_Halaman ${page + 1} dari ${totalPages}_`;
  }
  // ... keyboard tetap sama

  const keyboard = items.map(s => [{
    text: `Order ${s.kode}`,
    callback_data: `order_${s.kode}`
  }]);

  const nav = [];
  if (page > 0) nav.push({ text: "Prev", callback_data: `prodpage_${encodeURIComponent(category)}_${page - 1}` });
  if (start + PAGE_SIZE < services.length) nav.push({ text: "Next", callback_data: `prodpage_${encodeURIComponent(category)}_${page + 1}` });

  if (nav.length) keyboard.push(nav);
  keyboard.push([{ text: "Kembali ke Kategori", callback_data: "back_categories" }]);

  const options = {
    chat_id: chatId,
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: keyboard }
  };

  if (msgId) {
    options.message_id = msgId;
    return bot.editMessageText(text, options).catch(() => bot.sendMessage(chatId, text, options));
  } else {
    return bot.sendMessage(chatId, text, options);
  }
}

// ======= Pagination helpers for categories/subcategories/services =======


// Helper: Escape Markdown
function escapeMarkdown(text) {
  if (!text) return '';
  return text.replace(/[_*[\]()~>#+=|{}.!-]/g, '\\$&');
}

// Fetch layanan dari Triflazz



function parseHarga(hargaStr) {
  if (!hargaStr) return 0;
  const clean = hargaStr.toString().replace(/<[^>]+>/g, "").replace(/[^\d]/g, "");
  return parseInt(clean || "0", 10);
}

// ======================
// 🚀 FUNGSI FETCH UTAMA
// ======================



// di dalam fetchTriflazzServices gunakan:

async function fetchTriflazzServices(country = "Indonesia", search = "") {

const USER_AGENT = "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Mobile Safari/537.36";

  const url = "https://triflazz.com/ajax/layanan.php";

  // 🔹 body data
  const params = new URLSearchParams();
  params.append("search", search || "");
  params.append("country", country);

  // 🔹 header mirip browser
  const headers = {
    "Accept": "application/json, text/javascript, */*; q=0.01",
    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
    "X-Requested-With": "XMLHttpRequest",
    "Origin": "https://triflazz.com",
    "Referer": "https://triflazz.com/pemesanan/otp",
    "User-Agent": USER_AGENT,
    "Cookie": COOKIE_STRING,
  };

  try {

    const res = await axios.post(url, params.toString(), {
      headers,
      responseType: "json",
      validateStatus: s => s >= 200 && s < 500,
    });

    // Jika respon bukan JSON valid
    const data = typeof res.data === "string" ? JSON.parse(res.data) : res.data;
    if (!Array.isArray(data)) {
      console.error("❌ Response bukan array:", data);
      return [];
    }

    // 🔹 filter & rapikan data
    const services = data
      .filter(s => s.status === "Aktif" || s.status === "1")
      .map(s => ({
        id: s.id,
        nama: (s.nama || "").trim(),
        harga_asli: parseHarga(s.harga),
        tersedia: s.tersedia,
        is_promo: !!s.is_promo,
      }))
      .sort((a, b) => a.harga_asli - b.harga_asli);

 
    return services;

  } catch (err) {
    console.error("🚨 Fetch Error:", err.message);
    return [];
  }
}

// ======================

// ====== Event emitter (bot bisa listen) ======


// ====== Utility: ambil cookie dari session.json (dipakai fetch) ======


// ====== Safe wrapper fetch yang selalu membaca cookie terbaru ======
async function safeFetchTriflazzServices(country = "Malaysia", search = "") {
  // Ambil cookie terbaru dari file session.json, jika ada.
  
  // Jika fungsi fetchTriflazzServices menggunakan variabel COOKIE_STRING internal,
  // pastikan fetchTriflazzServices membaca getCookieString() di dalamnya.
  // Kalau belum, kita can override by wrapping axios; tapi asumsi: fetchTriflazzServices reads getCookieString().

  // Panggil fungsi fetch asli
  try {
    const services = await fetchTriflazzServices(country, search);
    return services;
  } catch (err) {
    if (!SILENT_MODE) console.error("safeFetchTriflazzServices error:", err.message);
    return [];
  }
}

// ====== Auto-fetch controller ======


// === triflazz-autofetch.js ===
// Jalankan di Node.js backend

const triflazzEvents = new EventEmitter();

// 30 detik
const SILENT_MODE = false;

// Data cache & state
let _autoFetchInterval = null;
let _isFetching = false;
let _lastResultHash = null;

// ====== Fungsi ambil data dari API Triflazz ======

// ====== Proses hasil fetch ======
async function handleFetchResult(country, category, services) {
  if (!Array.isArray(services)) return;

  const cheap = services.filter((s) => {
    const harga = Number(s.harga_asli || s.harga || s.price || 0);
    return harga > 0 && harga < 4400; // filter pakai harga asli
  });

  if (cheap.length > 0) {
  
    const sampleItems = cheap.slice(0, 5); // ambil contoh 5 item pertama

    const text =
      `🚨 *Harga Murah Terdeteksi !*\n\n` +
      `🌍 Negara: *${country}*\n📦 Kategori: *${category}*\n🛒 Jumlah Ditemukan: *${cheap.length}*\n\n` +
      sampleItems
        .map((s) => {
          const harga = Number(s.harga_asli || s.harga || s.price || 0);
          const hargaJual = Math.ceil(harga * (1 + PRICE_MARKUP));
          return `• ${s.nama || s.name || "Tanpa Nama"}\n  💰 Rp${hargaJual.toLocaleString("id-ID")}`;
        })
        .join("\n") +
      (cheap.length > 5 ? `\n\nDan ${cheap.length - 5} item lainnya...` : "");

    for (const user of subscribers) {
      try {
        await bot.sendMessage(user.id, text, { parse_mode: "Markdown" });
        console.log(`📩 Notifikasi dikirim ke ${user.name} (${user.id})`);
      } catch (err) {
        console.error(`❌ Gagal kirim ke ${user.name} (${user.id}):`, err.message);
      }
    }
  } else if (!SILENT_MODE) {
    // Jika tidak ada item murah dan mode tidak diam, bisa tambahkan log di sini
  }
}



// ====== Auto fetch loop ======
function startAutoFetch(opts = {}) {
  const countries = opts.countries || ["Indonesia", "Malaysia", "China", "Thailand", "Philipina"];
const POLL_INTERVAL_MS = 30_000; 
  const categories = opts.categories || ["whatsapp", "telegram"];
  const interval = typeof opts.intervalMs === "number" ? opts.intervalMs : POLL_INTERVAL_MS;
  const verbose = opts.verbose || !SILENT_MODE;

  if (_autoFetchInterval) {
    if (verbose) console.log("AutoFetch sudah berjalan.");
    return;
  }

  async function doFetch() {
    if (_isFetching) return;
    _isFetching = true;
    try {
      for (const country of countries) {
        for (const category of categories) {
          const services = await safeFetchTriflazzServices(country, category);
          handleFetchResult(country, category, services);
        }
      }
    } catch (e) {
      console.error("Error loop fetch:", e.message);
    } finally {
      _isFetching = false;
    }
  }

  // Jalankan pertama kali langsung
  doFetch();

  // Lalu looping
  _autoFetchInterval = setInterval(doFetch, interval);
  if (verbose) console.log(`🔁 AutoFetch dimulai (interval ${interval / 1000}s)`);
}

function stopAutoFetch() {
  if (_autoFetchInterval) {
    clearInterval(_autoFetchInterval);
    _autoFetchInterval = null;
    console.log("🛑 AutoFetch dihentikan.");
  }
}

// ====== Contoh penggunaan: broadcast ke semua user ======


// Ketika ada harga murah, kirim notifikasi ke semua user
triflazzEvents.on("cheap:found", async ({ country, category, items }) => {
  const sampleItems = items.slice(0, 5); // kirim contoh maksimal 5 item
  const text =
    `🚨 *Harga Murah Terdeteksi !*\n\n` +
    `🌍 Negara: *${country}*\n📦 Kategori: *${category}*\n🛒 Jumlah Ditemukan: *${items.length}*\n\n` +
    sampleItems
      .map(
        s =>
          `• ${s.nama || s.name || "Tanpa Nama"}\n  💰 Rp${Number(s.harga_asli || s.harga || 0).toLocaleString("id-ID")}`
      )
      .join("\n") +
    (items.length > 5 ? `\n\nDan ${items.length - 5} item lainnya...` : "");

  for (const user of subscribers) {
    try {
      await bot.sendMessage(user.id, text, { parse_mode: "Markdown" });
      console.log(`📩 Notifikasi dikirim ke ${user.name} (${user.id})`);
    } catch (err) {
      console.error(`❌ Gagal kirim ke ${user.name} (${user.id}):`, err.message);
    }
  }
});

// Jalankan otomatis
startAutoFetch({
  intervalMs: 60_000, // 1 menit
  verbose: true
});


// 1. Tampilkan daftar negara (bisa di-hardcode atau dinamis)
// Ganti fungsi showCategories lama dengan ini
async function showLayananCountries(chatId, page = 0, msgId = null) {
  const countries = [
    { name: "Malaysia", code: "malaysia", icon: "MY" },
    { name: "Indonesia", code: "indonesia", icon: "ID" },
    { name: "China", code: "china", icon: "SG" },
    { name: "Thailand", code: "thailand", icon: "TH" },
    { name: "Malaysia", code: "malaysia", icon: "PH" },
  ];

  const start = page * 5;
  const items = countries.slice(start, start + 5);
  const totalPages = Math.ceil(countries.length / 5);

  let text = `*Pilih Negara Layanan NoKOS* ${totalPages > 1 ? `(Hal ${page + 1})` : ""}\n\n`;
  items.forEach(c => {
    text += `${c.icon} *${c.name}*\n`;
  });

  const keyboard = items.map(c => [{
    text: `${c.icon} ${c.name}`,
    callback_data: `country_${c.code}`
  }]);

  const nav = [];
  if (page > 0) nav.push({ text: "Prev", callback_data: `layananpage_${page - 1}` });
  if (start + 5 < countries.length) nav.push({ text: "Next", callback_data: `layananpage_${page + 1}` });
  if (nav.length) keyboard.push(nav);

  keyboard.push([{ text: "Kembali ke Menu", callback_data: "back_main" }]);

  const options = {
    chat_id: chatId,
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: keyboard }
  };

  if (msgId) {
    return bot.editMessageText(text, { ...options, message_id: msgId }).catch(() =>
      bot.sendMessage(chatId, text, options)
    );
  } else {
    return bot.sendMessage(chatId, text, options);
  }
}

// 2. Tampilkan layanan per negara + search + paging

async function showServicesByCountry(chatId, country, page = 0, search = "", msgId = null) {
  const services = await fetchTriflazzServices(country, search);
  if (!services.length) {
    const text = search
      ? `Tidak ditemukan *"${escapeMarkdown(search)}"* di *${country}*`
      : `Tidak ada layanan aktif di *${country}*`;
    return bot.editMessageText(text, {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "Kembali", callback_data: "menu_layanan" }]] }
    }).catch(() => bot.sendMessage(chatId, text, { parse_mode: "Markdown" }));
  }

  const start = page * PAGE_SIZE;
  const items = services.slice(start, start + PAGE_SIZE);
  const totalPages = Math.ceil(services.length / PAGE_SIZE);

  let text = `*Layanan NoKOS - ${country.toUpperCase()}* (Hal ${page + 1}/${totalPages})\n`;
  if (search) text += `Pencarian: *${escapeMarkdown(search)}*\n`;
  text += "\n";

  items.forEach(s => {
    const hargaJual = Math.ceil(s.harga_asli * (1 + PRICE_MARKUP));
    text += `*${escapeMarkdown(s.nama)}*\n`;
    text += `Harga: *Rp ${hargaJual.toLocaleString('id-ID')}*\n`;
    text += `Tersedia: ${s.tersedia} | ID: \`${s.id}\`\n\n`;
  });

  const keyboard = items.map(s => [{
    text: `Order ${s.id}`,
    callback_data: `order_${s.id}`
  }]);

  const nav = [];
  if (page > 0) nav.push({ text: "Prev", callback_data: `srv_${country}_${page - 1}_${btoa(search)}` });
  if (start + PAGE_SIZE < services.length) nav.push({ text: "Next", callback_data: `srv_${country}_${page + 1}_${btoa(search)}` });
  if (nav.length) keyboard.push(nav);

  keyboard.push([
    { text: "Cari", callback_data: `search_${country}_${page}` },
    { text: "Kembali", callback_data: "menu_layanan" }
  ]);

  const options = { chat_id: chatId, parse_mode: "Markdown", reply_markup: { inline_keyboard: keyboard } };

  return bot.editMessageText(text, { ...options, message_id: msgId }).catch(() =>
    bot.sendMessage(chatId, text, options)
  );
}
// 3. Handler untuk tombol Search (minta input)
async function handleSearchRequest(chatId, country, currentPage, msgId) {
  const text = `🔍 *Cari layanan di ${country.toUpperCase()}*\n\nKetik nama layanan yang ingin dicari:`;
  const keyboard = [[{ text: "❌ Batal", callback_data: `country_${country}` }]];

  return bot.editMessageText(text, {
    chat_id: chatId,
    message_id: msgId,
    parse_mode: "Markdown",
    reply_markup: { inline_keyboard: keyboard }
  });
}


// ======= Entry points =======
bot.onText(/\/start(.*)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const user = {
    id: msg.chat.id,
    name: msg.chat.first_name || msg.from.username || "Tanpa Nama"
  };

  // Cek apakah sudah terdaftar
  if (!subscribers.some(u => u.id === user.id)) {
    // Tidak otomatis tambah ke subscribers lagi
  }

  await bot.sendMessage(
    user.id,
    `Halo *${user.name}*! 👋\nAktifkan notifikasi harga murah melalui menu utama.`,
    { parse_mode: "Markdown" }
  );

  users.add(chatId);
  persistUsers();

  const param = (match && match[1] || "").trim();

  if (!referrals[chatId]) {
    referrals[chatId] = { invitedBy: null, poin: 0, invites: [] }; // ganti points -> poin
  }

  // ✅ Referral aman anti duplikat
  if (param.startsWith("ref_")) {
    const inviterId = param.replace("ref_", "");

    if (inviterId !== String(chatId)) {
      // hanya kalau belum pernah diundang
      if (!referrals[chatId].invitedBy) {
        referrals[chatId].invitedBy = inviterId;

        if (!referrals[inviterId]) {
          referrals[inviterId] = { invitedBy: null, poin: 0, invites: [] };
        }

        // ✅ Hindari inviter dobel poin dari user sama
        if (!referrals[inviterId].invites.includes(chatId)) {
          referrals[inviterId].invites.push(chatId);
          referrals[inviterId].poin = (referrals[inviterId].poin || 0) + 1;
        }

        saveReferrals();

        bot.sendMessage(inviterId, `🎉 Kamu berhasil mengundang ${msg.from.first_name}!\nPoin kamu: ${referrals[inviterId].poin}`).catch(()=>{});
      }
    }
  }

  showMainMenu(chatId);
});

// keep users tracked on any message

// ======= Callback handler (all inline buttons) =======
bot.on("callback_query", async (cq) => {
  const chatId = cq.message.chat.id;
  const msgId = cq.message.message_id;
  const data = cq.data;
  const fromUsername = cq.from.username || "";




  bot.answerCallbackQuery(cq.id).catch(()=>{});

 if (data === "deposit") {
  console.log(`[DEBUG] User ${chatId} memilih menu deposit`);
  userState[chatId] = { step: "input_deposit" };
  return bot.sendMessage(chatId, "💵 Masukkan jumlah deposit (contoh: 20000):");
}

 if (data.startsWith("layananpage_")) {
    const page = parseInt(data.split("_")[1]);
    await showLayananCountries(chatId, page, msgId);
  }

   if (data.startsWith("country_")) {
    const country = data.split("_")[1];
    await showServicesByCountry(chatId, country, 0, "", msgId);
  }

  // === LAYANAN PER NEGARA + PAGINATION ===
   if (data.startsWith("srv_")) {
    const [, country, page, searchB64] = data.split("_");
    const search = searchB64 ? atob(searchB64) : "";
    await showServicesByCountry(chatId, country, parseInt(page), search, msgId);
  }

if (data === "toggle_notif") {
  const userIndex = subscribers.findIndex(s => s.id === chatId);
  const isSubscribed = userIndex !== -1;

  if (isSubscribed) {
    // Hapus dari subscribers
    subscribers.splice(userIndex, 1);
    saveSubscribers();
    await bot.editMessageText(
      "Notifikasi *dimatikan*.\nKamu tidak akan menerima info harga murah lagi.",
      {
        chat_id: chatId,
        message_id: msgId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "Aktifkan Lagi", callback_data: "toggle_notif" }],
            [{ text: "Kembali", callback_data: "back_main" }]
          ]
        }
      }
    );
  } else {
    // Tambah ke subscribers
    const user = {
      id: chatId,
      name: cq.from.first_name || cq.from.username || "User"
    };
    subscribers.push(user);
    saveSubscribers();
    await bot.editMessageText(
      "Notifikasi *diaktifkan*!\nKamu akan mendapat info saat ada harga murah.",
      {
        chat_id: chatId,
        message_id: msgId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "Matikan", callback_data: "toggle_notif" }],
            [{ text: "Kembali", callback_data: "back_main" }]
          ]
        }
      }
    );
  }
  return;
}

  // === CARI LAYANAN ===
   if (data.startsWith("search_")) {
    const [, country, page] = data.split("_");
    global.searchState = global.searchState || {};
    global.searchState[chatId] = { country, page: parseInt(page), msgId };

    await bot.editMessageText(`*Cari layanan di ${country.toUpperCase()}*\n\nKetik nama layanan:`, {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: [[{ text: "Batal", callback_data: "menu_layanan" }]] }
    });
  }

  // === ORDER ===
   if (data.startsWith("order_")) {
    const id = data.split("_")[1];
    await bot.sendMessage(chatId, `Order ID: *${id}*\nMasukkan User ID / Nomor tujuan:`, { parse_mode: "Markdown" });
  }

  if (data === "menu_layanan") return showLayananCountries(chatId, 0, msgId);

if (data === "menu_saldo") {
  return bot.editMessageText(`💰 Saldo kamu: Rp${getBalance(chatId)}`, {
    chat_id: chatId,
    message_id: msgId,
    reply_markup: {
      inline_keyboard: [
        [{ text: "➕ Deposit", callback_data: "deposit" }],
        [{ text: "⬅️ Back", callback_data: "back_main" }]
      ]
    }
  }).catch(()=>{});
}





if (data.startsWith("dompet_")) {
  const walletName = decodeURIComponent(data.replace("dompet_", ""));
  return showProductsByWallet(chatId, walletName, 0, msgId);
}

if (data.startsWith("dompetpage_")) {
  const page = parseInt(data.split("_")[1]) || 0;
  return showDompetWallets(chatId, page, msgId);
}

if (data.startsWith("dompetprod_")) {
  const parts = data.split("_");
  const wallet = decodeURIComponent(parts[1]);
  const page = parseInt(parts[2]) || 0;
  return showProductsByWallet(chatId, wallet, page, msgId);
}

if (data === "back_dompet_wallets") {
  return showDompetWallets(chatId, 0, msgId);
}

// Di dalam bot.on('callback_query', ...)
if (data.startsWith("prodpage_")) {
  const parts = data.split("_");
  const encCat = parts[1];
  const page = parseInt(parts[2]) || 0;
  const category = decodeURIComponent(encCat);
  return showProductsByCategory(chatId, category, page, msgId);
}

if (data === "back_categories") {
  return showCategories(chatId, 0, msgId);
}

  if (data === "menu_referral") {
    const link = makeReferralLink(chatId);
    return bot.editMessageText(`🔗 Referral link kamu:\n\`${link}\`\n\nBagikan untuk dapat poin.`, { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: { inline_keyboard: [[{ text: "⬅️ Back", callback_data: "back_main" }]] } }).catch(()=>{});
  }
  if (data === "menu_history") return showHistory(chatId, msgId);
  if (data === "menu_profile") {
    return showUserInfo(chatId, cq.from);
  }
  if (data === "menu_admin") {
    return bot.editMessageText("🔐 Admin login: tekan tombol di bawah untuk memeriksa akses (username Telegram harus cocok dengan daftar GitHub).", {
      chat_id: chatId,
      message_id: msgId,
      reply_markup: { inline_keyboard: [[{ text: "🔎 Cek Akses Admin", callback_data: "admin_check_access" }], [{ text: "⬅️ Back", callback_data: "back_main" }]] }
    }).catch(()=>{});
  }
  if (data === "back_main") return showMainMenu(chatId, msgId);
  if (data.startsWith("catpage_")) {
    const page = parseInt(data.split("_")[1]) || 0;
    return showCategories(chatId, page, msgId);
  }

 if (data === "menu_tukar_poin") {
  return showTukarPoinMenu(chatId, msgId);
}

if (data.startsWith("tukar_")) {
  if (!referrals[chatId]) {
    referrals[chatId] = { invitedBy: null, points: 0, invites: [] };
  }

  let cost = 0;
  let bonus = 0;

  if (data === "tukar_3") { cost = 3; bonus = 500; }
  else if (data === "tukar_5") { cost = 5; bonus = 750; }
  else if (data === "tukar_10") { cost = 10; bonus = 1500; }

  // Cek poin cukup atau tidak
  if (referrals[chatId].points < cost) {
    return bot.sendMessage(chatId, `⚠️ Poin kamu tidak cukup! Kamu hanya punya ${referrals[chatId].points} poin.`);
  }

  // Kurangi poin
  referrals[chatId].points -= cost;
  saveReferrals();

  // Tambah saldo
  addBalance(chatId, bonus);

  return bot.sendMessage(chatId, `✅ Berhasil tukar *${cost} poin* → +Rp${bonus}\n📊 Sisa poin kamu: ${referrals[chatId].points}`, {
    parse_mode: "Markdown"
  });
}

if (data.startsWith("maincat_")) {
  const catName = data.replace("maincat_", "");
  if (catName === "TOPUP") {
    return showTopupGames(chatId, 0, msgId);
  } else if (catName === "DOMPET DIGITAL") {
    return showDompetWallets(chatId, 0, msgId);  // <-- PISAH SUB-KATEGORI
  } else {
    return showProductsByCategory(chatId, catName, 0, msgId);
  }
}

if (data.startsWith("maincat_")) {
  const catName = data.replace("maincat_", "");
  if (catName === "TOPUP") {
    return showTopupGames(chatId, 0, msgId);
  } else {
    return showProductsByCategory(chatId, catName, 0, msgId);
  }
}

if (data.startsWith("game_")) {
  const gameName = decodeURIComponent(data.replace("game_", ""));
  return showProductsByGame(chatId, gameName, 0, msgId);
}

// Pagination game list
if (data.startsWith("gamepage_")) {
  const page = parseInt(data.split("_")[1]) || 0;
  return showTopupGames(chatId, page, msgId);
}

// Pagination produk game
if (data.startsWith("gameprod_")) {
  const parts = data.split("_");
  const game = decodeURIComponent(parts[1]);
  const page = parseInt(parts[2]) || 0;
  return showProductsByGame(chatId, game, page, msgId);
}

if (data === "back_topup_games") {
  return showTopupGames(chatId, 0, msgId);
}

if (data === "back_categories") {
  return showCategories(chatId, 0, msgId);
}

 if (data === "cek_pembayaran") {
    const trx = userState[chatId];
    if (!trx || trx.step !== "waiting_payment") {
      return bot.sendMessage(chatId, "⚠️ Tidak ada transaksi yang sedang dicek.");
    }

    const axios = require("axios");
    try {
      const url = `https://app.pakasir.com/api/transactiondetail?project=smm-bot&amount=${trx.amount}&order_id=${trx.orderId}&api_key=5SNVXO2RwRZnCNZjvBv0cd0x4FAxrmsf`;
      console.log("[DEBUG] Cek pembayaran:", url);

      const res = await axios.get(url);
      const status = res.data?.transaction?.status;
      console.log(`[DEBUG] Status pembayaran ${chatId}:`, status);

      if (status === "completed") {
        const bonus = trx.amount; // <-- kalau ada bonus tambahan tinggal ubah di sini
        addBalance(chatId, bonus);

        userState[chatId] = null;
        return bot.sendMessage(chatId, `✅ Pembayaran berhasil!\n💰 Saldo masuk: Rp${bonus}`);
      } else {
        return bot.sendMessage(chatId, "⏳ Pembayaran belum diterima. Coba lagi 30 detik lagi.");
      }
    } catch (err) {
      console.error("[ERROR] Cek pembayaran gagal:", err.response?.data || err.message);
      return bot.sendMessage(chatId, "❌ Gagal cek pembayaran. Coba beberapa saat lagi.");
    }
  }

if (data === "batal_deposit") {
  if (userState[chatId]?.messageId) {
    try {
      await bot.deleteMessage(chatId, userState[chatId].messageId);
    } catch (err) {
      console.log("[WARNING] Gagal hapus pesan QR:", err.message);
    }
  }

  userState[chatId] = null;
  return bot.sendMessage(chatId, "❌ Deposit dibatalkan.");
}





if (data.startsWith("cat_")) {
  const selectedCat = data.replace("cat_", "");
  return showProductsByCategory(chatId, selectedCat, 0, msgId);
}

  if (data.startsWith("subcatpage_")) {
    const parts = data.split("_");
    const encPlatform = parts[1];
    const page = parseInt(parts[2]) || 0;
    const platform = decodeURIComponent(encPlatform);
    return showSubCategories(chatId, platform, page, msgId);
  }
  if (data.startsWith("subcat_")) {
    const encoded = data.slice(7);
    const category = decodeURIComponent(encoded);
    return showServicesPage(chatId, category, 0, msgId);
  }
  if (data.startsWith("page_")) {
    const parts = data.split("_");
    const encodedCategory = parts[1];
    const page = parseInt(parts[2]) || 0;
    const category = decodeURIComponent(encodedCategory);
    return showServicesPage(chatId, category, page, msgId);
  }
  if (data.startsWith("back_cat_")) {
    const plat = decodeURIComponent(data.split("_")[2] || "");
    return showSubCategories(chatId, plat, 0, msgId);
  }
  if (data === "back_platform") return showCategories(chatId, 0, msgId);
    
if (data.startsWith("order_")) {
  const kode = data.replace("order_", "");
  const services = await fetchServices();
  const service = services.find(s => s.kode === kode);
  if (!service) {
    return bot.sendMessage(chatId, "Layanan tidak ditemukan.").catch(() => {});
  }

  pendingOrders[chatId] = {
    step: "target",
    service: {
      id: service.kode,
      name: service.keterangan,
      price: parseInt(service.harga), // harga asli dari OkeConnect
      min: 1,
      max: 999999
    },
    processing: false
  };

  return bot.sendMessage(chatId, `Order *${escapeMarkdown(service.keterangan)}*\n\nMasukkan ID Game Anda tanpa tanda kurung (ex: 123456 (2122) menjadi 1234562122):`, { parse_mode: "Markdown" });
}
    
 if (data === "admin_check_access") {
  const allowed = await fetchGithubAdmins();
  if (!Array.isArray(allowed) || !allowed.length) {
    return bot.editMessageText(
      "❌ Admin list not available (GitHub file unreachable).",
      { chat_id: chatId, message_id: msgId }
    ).catch(() => {});
  }

  const telegramUsername = cq.from.username || "";

  if (!allowed.includes(telegramUsername)) {
    return bot.editMessageText(
      "❌ Kamu tidak punya akses admin.",
      { chat_id: chatId, message_id: msgId }
    ).catch(() => {});
  }



  // 🆕 Tambah dua fitur baru di sini
  const kb = [
    [{ text: "📋 Daftar User", callback_data: "admin_list_users" }],
    [{ text: "💰 Topup Saldo", callback_data: "admin_topup" }],
    [{ text: "💵 Cek Saldo", callback_data: "admin_check_balance" }], // ✅ Baru
    [{ text: "💾 Backup Otomatis", callback_data: "admin_backup_auto" }], // ✅ Baru
    [{ text: "📣 Broadcast", callback_data: "admin_broadcast" }],
    [{ text: "⬅️ Back", callback_data: "back_main" }],
  ];

  return bot.editMessageText(
    "👑 Selamat datang Admin. Pilih aksi:",
    { chat_id: chatId, message_id: msgId, reply_markup: { inline_keyboard: kb } }
  ).catch(() => {});
}



async function fetchAdminBalance() {
  const payload = {
    api_id: API_ID,
    api_key: API_KEY
  };

  console.log("fetchAdminBalance: Sending API request with payload:", payload);

  try {
    const resp = await axios.post("https://fayupedia.id/api/balance", payload, { timeout: 15000 });
    console.log("fetchAdminBalance: API response:", {
      statusCode: resp.status,
      data: resp.data
    });

    const data = resp.data;

    if (data.status === true && typeof data.balance === "number") {
      return { success: true, balance: data.balance };
    }

    return { success: false, message: data.msg || "Respon tidak valid." };
  } catch (e) {
    console.error("fetchAdminBalance error:", {
      statusCode: e.response ? e.response.status : null,
      data: e.response ? e.response.data : null,
      message: e.message || e
    });
    return { success: false, message: "Gagal menghubungi server API." };
  }
}

if (data === "admin_check_balance") {
  await bot.editMessageText("💵 Mengecek saldo akun admin...", {
    chat_id: chatId,
    message_id: msgId
  }).catch(() => {});

  const result = await fetchAdminBalance();

  if (result.success) {
    const formatted = result.balance.toLocaleString("id-ID");
    return bot.editMessageText(
      `💰 *Saldo Akun Admin:*\nRp *${formatted}*`,
      {
        chat_id: chatId,
        message_id: msgId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🔄 Refresh", callback_data: "admin_check_balance" }],
            [{ text: "⬅️ Kembali", callback_data: "admin_check_access" }]
          ]
        }
      }
    ).catch(() => {});
  } else {
    return bot.editMessageText(
      `❌ Gagal mengambil saldo admin.\n🧾 Pesan: *${result.message}*`,
      {
        chat_id: chatId,
        message_id: msgId,
        parse_mode: "Markdown",
        reply_markup: {
          inline_keyboard: [
            [{ text: "🔄 Coba Lagi", callback_data: "admin_check_balance" }],
            [{ text: "⬅️ Kembali", callback_data: "admin_check_access" }]
          ]
        }
      }
    ).catch(() => {});
  }
}

    


async function uploadToGithub() {
  try {
const CHANNEL_ID = "-1003174207390"; // ganti dengan ID channel kamu
const name = "HeroPPOBBOTSC";
const zipName = `${name}.zip`;

    console.log("⏳ Membuat ZIP file otomatis...");

    // Buat ZIP tanpa node_modules dan folder sensitif
    execSync(`zip -r -q ${zipName} * -x "node_modules/*" "session/*" "*.zip" "*.log"`);
    console.log(`✅ ZIP dibuat: ${zipName}`);

    // Kirim file ke channel Telegram
    await bot.sendDocument(CHANNEL_ID, fs.createReadStream(zipName), {
      caption: `📦 Backup SC Bot\n🕒 ${new Date().toLocaleString("id-ID")}`
    });

    console.log("✅ Backup dikirim ke channel Telegram!");

    // Hapus file ZIP setelah dikirim
    execSync(`rm -rf ${zipName}`);

  } catch (err) {
    console.error("❌ Backup gagal:", err.message);
  }
}
    
  




if (data === "admin_backup_auto") {
  const status = autoBackupEnabled ? "🟢 ON" : "🔴 OFF";
  const lastTime = lastBackupTime
    ? new Date(lastBackupTime).toLocaleString("id-ID", { timeZone: "Asia/Makassar" })
    : "Belum pernah";

  const kb = [
    [
      { text: autoBackupEnabled ? "🚫 Matikan Auto Backup" : "✅ Nyalakan Auto Backup", callback_data: "toggle_auto_backup" }
    ],
    [
      { text: "⬅️ Kembali", callback_data: "admin_check_access" }
    ]
  ];

  return bot.editMessageText(
    `💾 *Status Backup Otomatis*\n\n` +
    `🧠 Status: ${status}\n` +
    `🕒 Backup terakhir: ${lastTime}\n\n` +
    `Silakan pilih untuk menyalakan atau mematikan backup otomatis.`,
    {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: kb }
    }
  ).catch(() => {});
}



async function showTukarPoinMenu(chatId, msgId = null) {
  // Ambil poin user (yang jadi inviter)
  const userReferralData = referrals[chatId];
  const poin = userReferralData?.points || 0;

  const teks = `🎁 *Tukar Poin*\n\n` +
    `📊 Poin kamu saat ini: *${poin}*\n\n` +
    `Pilih opsi tukar di bawah:`;

  const keyboard = [
    [{ text: "3 poin ➝ Rp500", callback_data: "tukar_3" }],
    [{ text: "5 poin ➝ Rp750", callback_data: "tukar_5" }],
    [{ text: "10 poin ➝ Rp1500", callback_data: "tukar_10" }],
    [{ text: "⬅️ Back", callback_data: "back_main" }]
  ];

  if (msgId) {
    return bot.editMessageText(teks, {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    });
  } else {
    return bot.sendMessage(chatId, teks, {
      parse_mode: "Markdown",
      reply_markup: { inline_keyboard: keyboard }
    });
  }
}




// fungsi panggil tokengrab.js (non-blocking)
function refreshTokenByProcess() {
  return new Promise((resolve, reject) => {
    // jalankan node tokengrab.js (pastikan node ada di PATH)
    const proc = spawn(process.execPath, [path.join(__dirname, "tokengrab.js")], {
      env: process.env
    });

    let stdout = "";
    proc.stdout.on("data", data => {
      stdout += data.toString();
      process.stdout.write(data); // optional: tampilkan output tokengrab ke console bot
    });

    proc.stderr.on("data", data => {
      process.stderr.write(data);
    });

    proc.on("close", code => {
      if (code === 0) {
        // baca session.json
        if (fs.existsSync(SESSION_FILE)) {
          const sess = JSON.parse(fs.readFileSync(SESSION_FILE, "utf8"));
          resolve(sess.cookie);
        } else {
          reject(new Error("session.json not found after tokengrab run"));
        }
      } else {
        reject(new Error("tokengrab process exited with code " + code));
      }
    });
  });
}





async function doAutoBackup() {
  const name = "HeroSMMBOTSC";
  const zipName = `${name}.zip`;

  try {
    console.log("⏳ Melakukan auto-backup...");

    // Buat list file yang akan di-zip
    const ls = execSync("ls")
      .toString()
      .split("\n")
      .filter(pe =>
        pe &&
        pe !== "node_modules" &&
        pe !== "session" &&
        pe !== "package-lock.json" &&
        pe !== "yarn.lock"
      );

    // Buat ZIP baru
    execSync(`zip -r -q ${zipName} ${ls.join(" ")}`);
    console.log(`✅ ZIP dibuat: ${zipName}`);

    // Upload ke GitHub (tertindih dengan nama file sama)
    await axios.put(
      `https://api.github.com/repos/DaffaHeroik/herosmmbot/contents/${zipName}`,
      {
        message: `Auto backup - ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Makassar" })}`,
        content: fs.readFileSync(zipName, { encoding: "base64" }),
        branch: "main"
      },
      {
        headers: {
          Authorization: `Bearer ${GITHUB_TOKEN}`,
          "User-Agent": "auto-backup-bot",
          Accept: "application/vnd.github.v3+json"
        }
      }
    );

    // Simpan waktu backup terakhir
    lastBackupTime = Date.now();

    console.log(`🕒 Backup berhasil pada ${new Date(lastBackupTime).toLocaleString("id-ID", { timeZone: "Asia/Makassar" })}`);

    // Hapus file zip lokal
    execSync(`rm -rf ${zipName}`);
  } catch (err) {
    console.error("❌ Auto-backup gagal:", err.message);
  }
}



if (data === "toggle_auto_backup") {
  autoBackupEnabled = !autoBackupEnabled;

  if (autoBackupEnabled) {
    await bot.editMessageText("✅ Auto Backup *dinyalakan*. Backup akan dilakukan setiap 3 jam sekali.", {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: "Markdown"
    }).catch(() => {});

    // Jalankan backup pertama segera
    uploadToGithub();

    // Jalankan otomatis setiap 3 jam (3 jam = 10800000 ms)
    autoBackupInterval = setInterval(uploadToGithub, 3 * 60 * 60 * 1000);

  } else {
    clearInterval(autoBackupInterval);
    autoBackupInterval = null;

    await bot.editMessageText("🚫 Auto Backup *dimatikan*.", {
      chat_id: chatId,
      message_id: msgId,
      parse_mode: "Markdown"
    }).catch(() => {});
  }
}




  if (data === "admin_list_users") {
    const arr = Array.from(users);
    let teks = `👥 Daftar Users (${arr.length}):\n\n`;
    const list = arr.slice(0, 200);
    list.forEach(u => {
      teks += `• ${u}\n`;
    });
    if (arr.length > list.length) teks += `\n...dan ${arr.length - list.length} user lainnya.`;
    return bot.sendMessage(chatId, teks).catch(()=>{});
  }
  if (data === "admin_topup") {
    adminPending[chatId] = { action: "topup" };
    return bot.sendMessage(chatId, "📥 Masukkan perintah topup dalam format:\n`userId jumlah`\nContoh: `123456789 50000`", { parse_mode: "Markdown" }).catch(()=>{});
  }
  if (data === "admin_broadcast") {
    adminPending[chatId] = { action: "broadcast" };
    return bot.sendMessage(chatId, "📣 Kirim pesan yang ingin dibroadcast ke semua user (masukkan di chat ini):").catch(()=>{});
  }
    


});
// ======= Message handler (order inputs, admin inputs, simple commands) =======
bot.on("message", async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text?.trim();

if (userState[chatId]?.step === "input_deposit") {
  console.log(`[DEBUG] User ${chatId} memasukkan nominal:`, text);

  const amount = parseInt(text);
  if (isNaN(amount) || amount < 1000) {
    console.warn(`[WARNING] Nominal tidak valid dari user ${chatId}:`, text);
    return bot.sendMessage(chatId, "⚠️ Nominal tidak valid, minimal 1000.");
  }

  const orderId = `HERO${Date.now()}`;
  console.log(`[DEBUG] Membuat orderID: ${orderId} untuk user ${chatId}`);

  try {
    const axios = require("axios");
    const QRCode = require("qrcode");

    console.log("[DEBUG] Mengirim request ke API Pakasir...");
    const res = await axios.post("https://app.pakasir.com/api/transactioncreate/qris", {
      project: "smm-bot",
      order_id: orderId,
      amount: amount,
      api_key: "5SNVXO2RwRZnCNZjvBv0cd0x4FAxrmsf"
    });

    console.log("[DEBUG] Response API Pakasir:", res.data);

    const qrisString = res.data?.payment?.payment_number;
    const fee = res.data?.payment?.fee;
    if (!qrisString) throw new Error("payment_number tidak ditemukan di response API!");

    const qrImage = await QRCode.toBuffer(qrisString);

    // kirim QR dulu
    const sentMessage = await bot.sendPhoto(chatId, qrImage, {
      caption: `✅ Deposit *Rp${amount}* berhasil dibuat!\n\n` +
               `🛍️ Fee *Rp${fee}*\n\n` +
               `📌 Order ID: *${orderId}*\n` +
               `⏳ Berlaku sampai: ${res.data.payment.expired_at}\n\n` +
               `Jika sudah transfer, klik tombol di bawah untuk cek status pembayaran.`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "✅ Saya sudah membayar", callback_data: "cek_pembayaran" }],
          [{ text: "❌ Batalkan", callback_data: "batal_deposit" }]
        ]
      }
    });

    // simpan state USER SETELAH pesan terkirim
    userState[chatId] = {
      step: "waiting_payment",
      amount: amount,
      orderId: orderId,
      messageId: sentMessage.message_id // simpan message_id di sini
    };

    console.log(`[SUCCESS] QR berhasil dikirim untuk ${chatId}`);
  } catch (err) {
    console.error("[ERROR] Gagal membuat QRIS deposit:", err.response?.data || err.message);
    bot.sendMessage(chatId, "❌ Gagal membuat transaksi QRIS. Silakan coba lagi.");
  }
}

  // Simpan user baru (cukup sekali)
  if (!users.has(chatId)) {
    users.add(chatId);
    persistUsers();
  }

  // Cek apakah sedang search layanan
  if (global.searchState?.[chatId]) {
    const { country, page, msgId } = global.searchState[chatId];
    delete global.searchState[chatId];
    if (!text || text === "Batal") {
      return showLayananCountries(chatId, 0, msgId);
    }
    return showServicesByCountry(chatId, country, page, text, msgId);
  }

  // Kalau bukan kondisi khusus, bisa diabaikan atau di-handle default
});

// graceful save on exit
process.on('SIGINT', async () => { try { saveReferrals(); persistUsers(); await saveBalancesToGithub(); await saveOrdersToGithub(); } catch(e){} process.exit(); });
process.on('SIGTERM', async () => { try { saveReferrals(); persistUsers(); await saveBalancesToGithub(); await saveOrdersToGithub(); } catch(e){} process.exit(); });
// Init balances and orders before running
(async () => {
  await initBalances();
  await initOrders();
  console.log("Bot is running...");
})();

// PERBAIKAN: Definisikan mainCategories di luar fungsi agar bisa diakses global
const mainCategories = [
  { name: "TOPUP", icon: "🎮", filter: s => s.kategori && s.kategori.toUpperCase().includes("DIGITAL") },
  { name: "DOMPET DIGITAL", icon: "🛍️", filter: s => s.kategori && s.kategori.toUpperCase().includes("DOMPET") },
  { name: "FINANCE", icon: "👥", filter: s => s.kategori && s.kategori.toUpperCase().includes("TAGIHAN") || s.kategori.toUpperCase().includes("FINANCE") },
  { name: "KUOTA", icon: "📥", filter: s => s.kategori && s.kategori.toUpperCase().includes("KUOTA") },
  { name: "PULSA", icon: "📲", filter: s => s.kategori && s.kategori.toUpperCase().includes("PULSA") },
  { name: "TOKEN PLN", icon: "⚡", filter: s => s.kategori && s.kategori.toUpperCase().includes("TOKEN PLN") }
];

