// bot.js - Rekber Bot v5.1 (FIX: Chat System + Semua Fitur)
const { Telegraf, Markup, session } = require('telegraf');
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const QRCode = require('qrcode');

const bot = new Telegraf('8386655036:AAG8H4RJ6ydjVVArhLBmA_9QIaIolW-r7X4');
bot.use(session());

const ADMIN_IDS = [6440970593]; // GANTI DENGAN ID ADMIN KAMU (dari log tadi)
const {
  generateRandomString,
  generateQRCode,
  checkPaymentStatus,
  downloadQRImage,
  formatNumber,
  cleanupQRFile
} = require('./depo.js');

// === DATA STORAGE ===
let rooms = {};
let history = {};
let balances = {};
const ROOMS_FILE = 'rooms.json';
const HISTORY_FILE = 'history.json';
const BALANCE_FILE = 'balances.json';
const UPLOAD_DIR = 'uploads';

if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);

const RATING_FILE = 'uploads/rating.json';
let ratings = {};

function loadRatings() {
  try {
    if (fs.existsSync(RATING_FILE)) {
      ratings = JSON.parse(fs.readFileSync(RATING_FILE, 'utf8'));
    }
  } catch (err) {
    console.error('[RATING LOAD ERROR]', err.message);
    ratings = {};
  }
}

function saveRatings() {
  fs.writeFileSync(RATING_FILE, JSON.stringify(ratings, null, 2));
}

// Panggil saat startup
loadRatings();
loadData(); // pastikan ini setelah loadRatings

// === LOAD & SAVE ===
function loadData() {
  try {
    if (fs.existsSync(ROOMS_FILE)) rooms = JSON.parse(fs.readFileSync(ROOMS_FILE, 'utf8'));
    if (fs.existsSync(HISTORY_FILE)) history = JSON.parse(fs.readFileSync(HISTORY_FILE, 'utf8'));
    if (fs.existsSync(BALANCE_FILE)) balances = JSON.parse(fs.readFileSync(BALANCE_FILE, 'utf8'));
    console.log(`[LOAD] Rooms: ${Object.keys(rooms).length}, Users: ${Object.keys(balances).length}`);
  } catch (err) {
    console.error('[ERROR] Load data:', err.message);
    rooms = {}; history = {}; balances = {};
  }
}

// === UTILS (TAMBAHKAN INI) ===




function saveData() {
  fs.writeFileSync(ROOMS_FILE, JSON.stringify(rooms, null, 2));
  fs.writeFileSync(HISTORY_FILE, JSON.stringify(history, null, 2));
  fs.writeFileSync(BALANCE_FILE, JSON.stringify(balances, null, 2));
}
loadData();

// === UTILS ===
const userState = {};
const ITEM_TYPES = { ACCOUNT: 'account', FILE: 'file', INGAME: 'ingame', OTHER: 'other' };

function formatRupiah(num) { return `Rp ${num.toLocaleString('id-ID')}`; }

function getUserRoom(userId) {
  return Object.entries(rooms).find(([_, room]) => room.users.includes(userId));
}

function getSellerRating(sellerId) {
  if (!ratings[sellerId] || ratings[sellerId].count === 0) {
    return `Rating: Belum ada ulasan`;
  }
  const avg = (ratings[sellerId].total / ratings[sellerId].count).toFixed(1);
  const full = '★'.repeat(Math.round(avg));
  const empty = '☆'.repeat(5 - Math.round(avg));
  return `Rating: *${avg}* ${full}${empty} (${ratings[sellerId].count} ulasan)`;
}

// CHAT FORWARD SYSTEM
function forwardMessage(fromId, toId, message, roomCode) {
  const prefix = fromId === rooms[roomCode].seller ? '👨‍💼 Penjual:' : '👤 Pembeli:';
  bot.telegram.sendMessage(toId, `${prefix} ${message}\n\nRoom: ${roomCode}`, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([[Markup.button.callback('Balas', `chat_${roomCode}`)]])
  });
}

function saveFile(fileId, filename) {
  return new Promise(async (resolve, reject) => {
    try {
      const file = await bot.telegram.getFile(fileId);
      const url = `https://api.telegram.org/file/bot${bot.token}/${file.file_path}`;
      const localPath = path.join(UPLOAD_DIR, filename);
      const writer = fs.createWriteStream(localPath);
      axios({ url, responseType: 'stream' })
        .then(r => r.data.pipe(writer))
        .then(() => writer.on('finish', () => resolve(localPath)))
        .catch(reject);
    } catch (err) { reject(err); }
  });
}

function addBalance(userId, amount) {
  balances[userId] = (balances[userId] || 0) + amount;
  saveData();
}

function addToHistory(userId, roomCode, role, item, amount, status = 'completed') {
  const entry = { roomCode, role, itemName: item.name, amount, timestamp: new Date().toLocaleString('id-ID'), status };
  if (!history[userId]) history[userId] = [];
  history[userId].push(entry);
  saveData();
}

// === COMMANDS ===
bot.start((ctx) => {
  ctx.reply('🤝 *Rekber Bot v5.1*\n\nFitur:\n• Anti-penipuan\n• QRIS otomatis\n• Chat aman\n• Admin panel\n• Refund', Markup.inlineKeyboard([
    [Markup.button.callback('Buat Room', 'create_room')],
    [Markup.button.callback('Deposit', 'deposit')],
    [Markup.button.callback('History', 'history')],
    [Markup.button.callback('Saldo', 'balance')]
  ]), { parse_mode: 'Markdown' });
});

// === ADMIN PANEL ===
bot.command('admin', (ctx) => {
  if (!ADMIN_IDS.includes(ctx.from.id)) return ctx.reply('❌ Akses ditolak!');
  
  const activeRooms = Object.entries(rooms).map(([code, room]) => {
    const total = room.items.reduce((a, b) => a + b.price, 0);
    return `• *${code}*: ${room.status} | ${formatRupiah(total)}`;
  }).join('\n') || 'Kosong';

  const topBalances = Object.entries(balances)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 5)
    .map(([id, bal]) => `• ${id}: ${formatRupiah(bal)}`)
    .join('\n') || 'Kosong';

  const todayHistory = Object.values(history).flat()
    .filter(h => new Date(h.timestamp).toDateString() === new Date().toDateString())
    .slice(0, 5)
    .map(h => `• ${h.itemName}: ${formatRupiah(h.amount)} (${h.status})`)
    .join('\n') || 'Kosong';

  ctx.reply(
    `🔧 *ADMIN PANEL*\n\n` +
    `📊 *Transaksi Aktif* (${Object.keys(rooms).length}):\n${activeRooms}\n\n` +
    `💰 *Saldo User* (Top 5):\n${topBalances}\n\n` +
    `📈 *History Hari Ini* (${Object.values(history).flat().filter(h => new Date(h.timestamp).toDateString() === new Date().toDateString()).length}):\n${todayHistory}\n\n` +
    `Total Revenue: ${formatRupiah(Object.values(balances).reduce((a,b) => a + b, 0))}`,
    {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('📢 Broadcast', 'admin_broadcast')],
        [Markup.button.callback('🚫 Force Cancel', 'admin_cancel')],
        [Markup.button.callback('🔄 Refresh', 'admin_refresh')]
      ])
    }
  );
});

bot.action('cancel_chat', (ctx) => {
  delete userState[ctx.from.id];
  ctx.deleteMessage().catch(() => {});
  ctx.answerCbQuery('Chat dibatalkan.');
});

// === CHAT SYSTEM ===
bot.action(/chat_(.+)/, (ctx) => {
  const code = ctx.match[1];
  const room = rooms[code];
  if (!room) return ctx.answerCbQuery('Room tidak ditemukan!');
  
  // CEK: USER MASIH DI ROOM?
  if (!room.users.includes(ctx.from.id)) {
    return ctx.answerCbQuery('Kamu sudah keluar dari room ini!');
  }

  const toId = ctx.from.id === room.seller ? room.buyer : room.seller;
  if (!toId || !room.users.includes(toId)) {
    return ctx.answerCbQuery('Partner sudah keluar dari room!');
  }

  userState[ctx.from.id] = { step: 'chat_message', roomCode: code, to: toId };

  ctx.reply(
    'Kirim pesan ke partner:\n\n' +
    '• Tanya kualitas\n' +
    '• Nego harga\n\n' +
    'Jangan kirim data sensitif!',
    {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([[Markup.button.callback('Batal', 'cancel_chat')]])
    }
  );

  ctx.answerCbQuery();
});

// CHAT FORWARD SYSTEM (Tambah validasi)
function forwardMessage(fromId, toId, message, roomCode) {
  const room = rooms[roomCode];
  if (!room || !room.users.includes(fromId) || !room.users.includes(toId)) {
    bot.telegram.sendMessage(fromId, 'Partner sudah keluar. Pesan tidak terkirim.');
    return;
  }

  const prefix = fromId === room.seller ? 'Penjual:' : 'Pembeli:';
  bot.telegram.sendMessage(toId, `${prefix} ${message}\n\nRoom: ${roomCode}`, {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([[Markup.button.callback('Balas', `chat_${roomCode}`)]])
  });
}




// === CREATE ROOM ===
bot.action('create_room', (ctx) => {
  const code = Math.random().toString(36).substring(2, 8).toUpperCase();
rooms[code] = { 
  code, 
  users: [ctx.from.id], 
  seller: ctx.from.id, 
  sellerUsername: ctx.from.username || `User_${ctx.from.id}`, // TAMBAHKAN INI
  buyer: null, 
  items: [], 
  status: 'waiting' 
};
  saveData();
  ctx.editMessageText(`✅ *Room dibuat!*\n\n🔑 *Kode:* \`${code}\`\n\n📱 Bagikan kode ini ke pembeli.\n💬 Chat akan aktif setelah pembeli join.`, { parse_mode: 'Markdown' });
});

// === JOIN ROOM ===
bot.command('join', async (ctx) => {
  const match = ctx.message.text.match(/\/join\s+([A-Z0-9]+)/i);
  if (!match) return ctx.reply('❌ Format: `/join KODE`\nContoh: `/join ABC123`', { parse_mode: 'Markdown' });
  
  const code = match[1].toUpperCase();
  if (!rooms[code]) return ctx.reply('❌ Kode room tidak valid atau sudah kadaluarsa!');
  
  const room = rooms[code];
  if (room.users.includes(ctx.from.id)) return ctx.reply('⚠️ Kamu sudah di room ini!');
  if (room.users.length >= 2) return ctx.reply('❌ Room sudah penuh! (2/2)');

  room.users.push(ctx.from.id);
  room.buyer = ctx.from.id;
  room.status = 'connected';
  saveData();

  ctx.reply(
    `✅ *Berhasil join room ${code}*\n\n` +
    `👤 Kamu: *Pembeli*\n` +
    `👨‍💼 Penjual: @${room.sellerUsername}\n` +
     getSellerRating(room.seller) + `\n\n` +
    `💬 Chat dengan penjual sekarang aktif!\n` +
    `Kirim pesan via tombol "Chat" di bawah.`,
    { 
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([[Markup.button.callback('💬 Chat', `chat_${code}`)]])
    }
  );

  // Notify penjual
  bot.telegram.sendMessage(room.seller, 
    `🎉 *Pembeli telah join room ${code}*!\n\n` +
    `👤 Pembeli: @${ctx.from.username || ctx.from.first_name}\n` +
    `💰 Total: Menunggu item\n\n` +
    `💬 Chat sekarang aktif! Gunakan tombol "Chat" untuk komunikasi.`,
    { 
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('➕ Add Item', `additem_${code}`)],
        [Markup.button.callback('💬 Chat', `chat_${code}`)],
[Markup.button.callback('Keluar', `leave_room_${code}`)],
          [Markup.button.callback('Status Room', `status_${code}`)]
      ])
    }
  );
});

// === LEAVE ROOM === (Tambah pembersihan & notif)
bot.command('leave', (ctx) => {
  const [code, room] = getUserRoom(ctx.from.id) || [];
  if (!room) return ctx.reply('Kamu tidak di room manapun!');

  const otherUser = room.users.find(u => u !== ctx.from.id);

  // HAPUS USER DARI ROOM
  room.users = room.users.filter(u => u !== ctx.from.id);

  // HAPUS USERSTATE
  delete userState[ctx.from.id];

  // NOTIF PARTNER
  if (otherUser) {
    bot.telegram.sendMessage(otherUser,
      `*Partner telah keluar dari room ${code}*\n\n` +
      `Chat & transaksi dibatalkan.\n` +
      `Gunakan /start untuk buat room baru.`,
      { parse_mode: 'Markdown' }
    );
  }

  // RESET ROOM JIKA KOSONG
  if (room.users.length === 0) {
    delete rooms[code];
  } else if (room.buyer === ctx.from.id) {
    room.buyer = null;
    room.status = 'waiting';
  } else if (room.seller === ctx.from.id) {
    delete rooms[code];
  }

  saveData();
  ctx.reply('Kamu keluar dari room. Chat & transaksi dibatalkan.');
});

// === DEPOSIT (DETAIL FEE) ===
bot.action('deposit', (ctx) => {
  userState[ctx.from.id] = { step: 'input_deposit' };
  ctx.editMessageText('💵 Masukkan jumlah deposit (minimal Rp 1.000):');
});

bot.action('batal_deposit', async (ctx) => {
  const state = userState[ctx.from.id];
  if (!state?.messageId) return ctx.answerCbQuery('Tidak ada deposit aktif.');

  try {
    // Edit caption dari pesan foto QRIS
    await ctx.editMessageCaption({
      caption: 'DEPOSIT DIBATALKAN\n\nTransaksi telah dibatalkan oleh user.',
      parse_mode: 'Markdown'
    });

    // Hapus file QR
    if (state.qrFile) cleanupQRFile(state.qrFile);

    // Hapus state
    delete userState[ctx.from.id];
    ctx.answerCbQuery('Deposit dibatalkan.');
  } catch (err) {
    console.error('[BATAL DEPOSIT ERROR]', err.message);
    ctx.answerCbQuery('Gagal membatalkan. Coba lagi.');
  }
});

function escapeMarkdown(text = '') {
  return text
    .replace(/\\/g, '\\\\') // Escape backslash dulu
    .replace(/([_*[\]()~`>#+\-=|{}.!])/g, '\\$1'); // Escape karakter Markdown
}


// === 1 TEXT HANDLER (SEMUA FITUR) ===
bot.on('text', async (ctx) => {
  const chatId = ctx.from.id;
  const text = ctx.message.text.trim();
  const state = userState[chatId];
  if (!state || !state.step) return;

  console.log(`[TEXT] ${chatId} | ${state.step} | ${text}`);

  // ADMIN BROADCAST
  if (state.step === 'broadcast') {
    let sent = 0;
    Object.keys(balances).forEach(async (userId) => {
      try {
        await bot.telegram.sendMessage(userId, `📢 *Broadcast Admin*\n\n${text}`, { parse_mode: 'Markdown' });
        sent++;
      } catch (err) { console.log(`[BROADCAST ERROR] ${userId}:`, err.message); }
    });
    delete userState[chatId];
    ctx.reply(`✅ Broadcast terkirim ke ${sent} user!`);
    return;
  }

  // ADMIN CANCEL ROOM
  if (state.step === 'cancel_room') {
    const code = text.toUpperCase();
    if (rooms[code]) {
      const room = rooms[code];
      const total = room.items.reduce((a, b) => a + b.price, 0);
      if (room.buyer && room.status === 'waiting_payment') {
        addBalance(room.buyer, total);
        bot.telegram.sendMessage(room.buyer, `💰 *Refund dari Admin*\n\nRoom ${code} dibatalkan oleh admin.\nSaldo: ${formatRupiah(balances[room.buyer])}`, { parse_mode: 'Markdown' });
      }
      delete rooms[code];
      saveData();
      ctx.reply(`✅ Room *${code}* dibatalkan & direfund.`, { parse_mode: 'Markdown' });
    } else {
      ctx.reply('❌ Room tidak ditemukan!');
    }
    delete userState[chatId];
    return;
  }

  // CHAT MESSAGES


  // DEPOSIT
  // GANTI bagian if (state.step === 'input_deposit')
if (state.step === 'input_deposit') {
  const amount = parseInt(text);
  if (isNaN(amount) || amount < 10) return ctx.reply('Minimal Rp 10!');

  const idTransaksi = `DEP-${Date.now()}-${chatId}`;
  console.log(`[DEPOSIT] Membuat QR untuk ${amount}...`);

  const qrResult = await generateQRCode(amount, idTransaksi);
  if (!qrResult.success) {
    console.error('[ZENITSU ERROR]', qrResult.error);
    return ctx.reply('Gagal buat QRIS. Coba lagi.');
  }

  const { qrUrl, expired, amount: qrAmount } = qrResult.data;
  const fee = 0; // Zenitsu biasanya tanpa fee
  const totalPay = parseInt(qrAmount);

  // Download QR
  const qrFile = await downloadQRImage(qrUrl, `qris-depo-${idTransaksi}.png`);

  const caption = 
    `*DEPOSIT*\n\n` +
    `Nominal: *${formatRupiah(amount)}*\n` +
    `Biaya Admin: *Rp 0*\n` +
    `Total Bayar: *${formatRupiah(totalPay)}*\n\n` +
    `Order ID: \`${idTransaksi}\`\n` +
    `Berlaku hingga: ${expired.toLocaleString('id-ID')}\n\n` +
    `Scan QRIS & transfer sekarang. Klik "Sudah Transfer" setelah bayar.`;

  const sent = await ctx.replyWithPhoto(
    { source: qrFile },
    {
      caption,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: "Sudah Transfer", callback_data: `cekdep_${idTransaksi}` }],
          [{ text: "Batal", callback_data: 'batal_deposit' }]
        ]
      }
    }
  );

  userState[chatId] = {
    step: 'waiting_deposit',
    orderId: idTransaksi,
    messageId: sent.message_id,
    amount,
    qrFile // simpan path untuk cleanup
  };

  console.log(`[DEPOSIT] QRIS Zenitsu dibuat: ${idTransaksi}`);
  return;
}

  // ADD ITEM
  if (state.step === 'additem_name') {
    if (text.length < 3 || text.length > 50) return ctx.reply('❌ Nama item harus 3-50 karakter!');
    userState[chatId] = { ...state, step: 'additem_price', itemName: text };
    return ctx.reply('💰 Masukkan *harga* (contoh: 50000):', { parse_mode: 'Markdown' });
  }

  if (state.step === 'additem_price') {
    const price = parseInt(text.replace(/\D/g, ''));
    if (isNaN(price) || price < 10) return ctx.reply('❌ Harga minimal Rp 10!');
    userState[chatId] = { ...state, step: 'additem_input', itemPrice: price };
    const hint = { 
      account: 'email:password (akan disembunyikan dari pembeli)', 
      file: 'kirim file/gambar', 
      ingame: 'detail item (ID, server)', 
      other: 'deskripsi lengkap' 
    }[state.itemType] || 'data item';
    return ctx.reply(`📦 Kirim *${hint}* untuk item "${state.itemName}":`, { parse_mode: 'Markdown' });
  }

  if (state.step === 'additem_input') {
    const room = rooms[state.roomCode];
    if (!room) { delete userState[chatId]; return ctx.reply('❌ Room hilang. Mulai ulang.'); }
    

const item = {
  name: state.itemName,
  price: state.itemPrice,
  type: state.itemType,
  data: text,
  filePath: null
};
room.items = [item];
room.status = 'item_added';
room.vote = { buyer: null, seller: null }; 
saveData();
    delete userState[chatId];
    
    const total = item.price;
const itemNameEsc = escapeMarkdown(state.itemName);
const dataEsc = escapeMarkdown(text);

    // Penjual lihat data lengkap
    ctx.reply(
      `✅ *Item berhasil ditambahkan!*\n\n` +
      `📦 *${itemNameEsc}*\n` +
      `💰 ${formatRupiah(total)}\n` +
      `📝 Data: \`${dataEsc}\`\n\n` +
      `⏳ Menunggu pembeli untuk bayar...\n` +
      `💬 Gunakan tombol "Chat" untuk komunikasi.`,
      { 
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('💬 Chat', `chat_${room.code}`)],
          [Markup.button.callback('📊 Status Room', `status_${room.code}`)]
        ])
      }
    );

    // Pembeli lihat preview TANPA DATA
    bot.telegram.sendMessage(room.buyer, 
      `🛒 *ITEM TRANSAKSI BARU*\n\n` +
      `📦 *${escapeMarkdown(item.name)}*\n` +
      `💰 Harga: ${formatRupiah(total)}\n\n` +
      `💳 Total: *${formatRupiah(total)}*\n\n` +
      `⚠️ Data akan dikirim *SETELAH* pembayaran selesai.\n\n` +
      `💬 Chat dengan penjual untuk tanya detail:`,
      { 
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback(`💳 Bayar ${formatRupiah(total)}`, `pay_${room.code}`)],
          [Markup.button.callback('💬 Chat Penjual', `chat_${room.code}`)]
        ])
      }
    );
    return;
  }

if (state.step === 'chat_message') {
  const room = rooms[state.roomCode];
  if (!room || !room.users.includes(chatId) || !room.users.includes(state.to)) {
    delete userState[chatId];
    return ctx.reply('Partner sudah keluar. Chat dibatalkan.');
  }

  forwardMessage(chatId, state.to, text, state.roomCode);
  delete userState[chatId];
  ctx.reply('Pesan terkirim!');
  return;
}

  if (state.step === 'complain') {
    ctx.reply('📸 Kirim *bukti gagal login* (screenshot error):', { parse_mode: 'Markdown' });
  }
});



// === UPLOAD FILE (ADD ITEM & KOMPLAIN) ===
bot.on(['photo', 'document'], async (ctx) => {
  const chatId = ctx.from.id;
  const state = userState[chatId];
const itemNameEsc = escapeMarkdown(state.itemName);
  
  // ADD ITEM: UPLOAD FILE
  if (state?.step === 'additem_input') {
    const room = rooms[state.roomCode];
    if (!room) return ctx.reply('❌ Room hilang.');
    
    let fileId, fileName, fileType;
    if (ctx.message.photo) {
      fileId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
      fileName = `item_${Date.now()}.jpg`;
      fileType = 'photo';
    } else if (ctx.message.document) {
      fileId = ctx.message.document.file_id;
      fileName = ctx.message.document.file_name || `file_${Date.now()}`;
      fileType = 'document';
    } else return;

    try {
      const localPath = await saveFile(fileId, fileName);
      const item = { 
        name: state.itemName, 
        price: state.itemPrice, 
        type: state.itemType, 
        data: null, 
        filePath: localPath, 
        fileType 
      };
      
      room.items = [item]; 
      room.status = 'item_added'; 
      saveData(); 
      delete userState[chatId];
      
      const total = item.price;
const itemNameEsc = escapeMarkdown(state.itemName);
  const fileNameEsc = escapeMarkdown(fileName);

      // Penjual konfirmasi
ctx.reply(
  `✅ *Item + file berhasil ditambahkan!*\n\n` +
  `📦 *${itemNameEsc}*\n` +
  `💰 ${formatRupiah(total)}\n` +
  `📎 File: ${fileNameEsc}\n\n` +
  `Menunggu pembeli bayar...`,
        { 
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback('💬 Chat', `chat_${room.code}`)],
            [Markup.button.callback('📊 Status', `status_${room.code}`)]
          ])
        }
      );

      // Pembeli preview (TANPA FILE)
      bot.telegram.sendMessage(room.buyer, 
        `🛒 *ITEM TRANSAKSI BARU*\n\n` +
        `📦 *${itemNameEsc}*\n` +
        `💰 Harga: ${formatRupiah(total)}\n\n` +
        `💳 Total: *${formatRupiah(total)}*\n\n` +
        `📎 *File terlampir* (dikirim setelah bayar)\n\n` +
        `💬 Tanya detail ke penjual:`,
        { 
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [Markup.button.callback(`💳 Bayar ${formatRupiah(total)}`, `pay_${room.code}`)],
            [Markup.button.callback('💬 Chat Penjual', `chat_${room.code}`)]
          ])
        }
      );
    } catch (err) {
      console.error('[UPLOAD ERROR]', err);
      ctx.reply('❌ Gagal upload file. Coba lagi.');
    }
    return;
  }

  // KOMPLAIN: UPLOAD BUKTI
  if (state?.step === 'complain') {
    const room = rooms[state.roomCode];
    if (!room) return ctx.reply('❌ Room hilang.');
    
    if (!ctx.message.photo) return ctx.reply('❌ Harus kirim foto/screenshot bukti gagal!');
    
    try {
      const fileId = ctx.message.photo[ctx.message.photo.length - 1].file_id;
      const proofPath = await saveFile(fileId, `complain_${Date.now()}.jpg`);
      room.complainProof = proofPath; 
      room.status = 'disputed'; 
      saveData(); 
      delete userState[chatId];
      
      ctx.reply('✅ *Bukti komplain diterima!*\n\n⏳ Menunggu penjual review...', { parse_mode: 'Markdown' });

      // Kirim bukti ke penjual
      await bot.telegram.sendPhoto(room.seller, { source: proofPath }, {
        caption: `🚨 *PEMBELI MENGOMPLAIN!*\n\nRoom: ${room.code}\nItem: ${room.items[0].name}\nTotal: ${formatRupiah(room.items[0].price)}\n\n📸 Lihat bukti gagal login di bawah.\n\nPilih tindakan:`,
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [Markup.button.callback('✅ Terima & Refund', `refund_${room.code}`)],
          [Markup.button.callback('❌ Tolak Komplain', `reject_${room.code}`)]
        ])
      });

      // Notify admin
      ADMIN_IDS.forEach(adminId => {
        bot.telegram.sendMessage(adminId, 
          `⚠️ *KOMPLAIN BARU*\n\nRoom: ${room.code}\nStatus: Disputed\nTotal: ${formatRupiah(room.items[0].price)}`,
          { parse_mode: 'Markdown' }
        );
      });
    } catch (err) {
      console.error('[KOMPLAIN ERROR]', err);
      ctx.reply('❌ Gagal upload bukti. Coba lagi.');
    }
  }
});



// === ADD ITEM BUTTONS ===
bot.action(/additem_(.+)/, (ctx) => {
  const code = ctx.match[1];
  const room = rooms[code];
  if (!room || room.seller !== ctx.from.id) return ctx.answerCbQuery('❌ Bukan penjual!');
  
  userState[ctx.from.id] = { step: 'additem_type', roomCode: code };
  ctx.reply('📦 *Pilih Tipe Item*:', {
    parse_mode: 'Markdown',
    ...Markup.inlineKeyboard([
      [Markup.button.callback('👤 Akun Login', `type_${code}_account`), Markup.button.callback('📎 File', `type_${code}_file`)],
      [Markup.button.callback('🎮 Item Game', `type_${code}_ingame`), Markup.button.callback('📝 Lainnya', `type_${code}_other`)]
    ])
  });
});

bot.action(/type_(.+)_(.+)/, (ctx) => {
  const [code, type] = [ctx.match[1], ctx.match[2]];
  const room = rooms[code];
  if (!room || room.seller !== ctx.from.id) return ctx.answerCbQuery('❌ Error!');
  
  userState[ctx.from.id] = { step: 'additem_name', roomCode: code, itemType: type };
  ctx.editMessageText('📝 Masukkan *nama item* (contoh: "Akun Netflix Premium"):', { parse_mode: 'Markdown' });
});

// === PAYMENT (DETAIL FEE + NOTIFICATION) ===
// GANTI bot.action(/pay_(.+)/, ...)
bot.action(/pay_(.+)/, async (ctx) => {
  const code = ctx.match[1];
  const room = rooms[code];
  if (!room || room.buyer !== ctx.from.id) return ctx.answerCbQuery('Bukan pembeli!');

  if (room.items.length === 0) return ctx.answerCbQuery('Belum ada item!');

  const total = room.items.reduce((a, b) => a + b.price, 0);
  const idTransaksi = `PAY-${Date.now()}-${code}`;

  const qrResult = await generateQRCode(total, idTransaksi);
  if (!qrResult.success) {
    console.error('[ZENITSU PAY ERROR]', qrResult.error);
    return ctx.answerCbQuery('Gagal buat QRIS!');
  }

  const { qrUrl, expired } = qrResult.data;
  const qrFile = await downloadQRImage(qrUrl, `qris-pay-${idTransaksi}.png`);

  const caption = 
    `*PEMBAYARAN REKBER*\n\n` +
    `Item: *${escapeMarkdown(room.items[0].name)}*\n` +
    `Harga: *${formatRupiah(total)}*\n` +
    `Biaya Admin: *Rp 0*\n` +
    `━━━━━━━━━━━━━━━━\n` +
    `*Total Bayar: ${formatRupiah(total)}*\n\n` +
    `Order ID: \`${idTransaksi}\`\n` +
    `Berlaku hingga: ${expired.toLocaleString('id-ID')}\n\n` +
    `Transfer sekarang & klik "Sudah Transfer".`;

  const sent = await ctx.replyWithPhoto(
    { source: qrFile },
    {
      caption,
      parse_mode: 'Markdown',
      reply_markup: {
        inline_keyboard: [
          [{ text: "Sudah Transfer", callback_data: `cek_${idTransaksi}` }],
          [{ text: "Batal", callback_data: `cancel_${code}` }]
        ]
      }
    }
  );

  room.orderId = idTransaksi;
  room.qrisMessageId = sent.message_id;
  room.qrFile = qrFile; // simpan path
  room.status = 'waiting_payment';
  saveData();

  // Notifikasi penjual
  bot.telegram.sendMessage(room.seller,
    `*PEMBELI SEDANG BAYAR!*\n\n` +
    `Room: *${code}*\n` +
    `Item: ${room.items[0].name}\n` +
    `Total: *${formatRupiah(total)}*\n` +
    `Order ID: \`${idTransaksi}\`\n\n` +
    `Cek status:`,
    {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('Cek Bayar', `seller_check_${idTransaksi}`)],
        [Markup.button.callback('Status Room', `status_${code}`)]
      ])
    }
  );

  // Notify admin
  ADMIN_IDS.forEach(id => {
    bot.telegram.sendMessage(id,
      `*TRANSAKSI BARU*\nRoom: ${code}\nTotal: ${formatRupiah(total)}\nStatus: Waiting Payment`,
      { parse_mode: 'Markdown' }
    );
  });
});

// === CEK PEMBAYARAN ===

// === PENJUAL CEK BAYAR ===
bot.action(/seller_check_(.+)/, async (ctx) => {
  const orderId = ctx.match[1];
  const [code, room] = Object.entries(rooms).find(([_, r]) => r.orderId === orderId) || [];
  if (!room) return ctx.answerCbQuery('❌ Room tidak ditemukan!');

  const total = room.items.reduce((a, b) => a + b.price, 0);
  try {
    const res = await axios.get(`https://app.pakasir.com/api/transactiondetail?project=smm-bot&amount=${total}&order_id=${orderId}&api_key=5SNVXO2RwRZnCNZjvBv0cd0x4FAxrmsf`);
    const status = res.data?.transaction?.status;
    
    if (status === 'completed') {
      ctx.editMessageText(
        `✅ *PEMBAYARAN SUDAH MASUK!*\n\n` +
        `📦 Room: *${code}*\n` +
        `💰 Total: ${formatRupiah(total)}\n` +
        `📱 Order: ${orderId}\n\n` +
        `🎉 Item sudah otomatis dikirim ke pembeli.\n` +
        `⭐ Minta rating dari pembeli.`,
        { parse_mode: 'Markdown' }
      );
    } else {
      ctx.answerCbQuery(`⏳ Status: *${status || 'pending'}*\nCek lagi 10 detik...`, { show_alert: true, parse_mode: 'Markdown' });
    }
  } catch (err) {
    ctx.answerCbQuery('❌ Gagal cek. Coba lagi.');
  }
});

// Handler rating 1-5
bot.action(/rate_(.+)_([1-5])/, async (ctx) => {
  const code = ctx.match[1];
  const star = parseInt(ctx.match[2]);
  const room = rooms[code];

  if (!room || room.buyer !== ctx.from.id) {
    return ctx.answerCbQuery('Kamu bukan pembeli!');
  }

  if (room.rated) {
    return ctx.answerCbQuery('Kamu sudah beri rating!');
  }

  const sellerId = room.seller;

  // Simpan rating
  if (!ratings[sellerId]) ratings[sellerId] = { total: 0, count: 0, stars: [] };
  ratings[sellerId].total += star;
  ratings[sellerId].count += 1;
  ratings[sellerId].stars.push(star);

  room.rated = true; // tanda sudah rating
  saveData();
  saveRatings();

  // Hitung rata-rata
  const avg = (ratings[sellerId].total / ratings[sellerId].count).toFixed(1);
  const starDisplay = '★'.repeat(Math.round(avg)) + '☆'.repeat(5 - Math.round(avg));

  // Edit pesan jadi terima kasih + rating
  await ctx.editMessageText(
    `*TERIMA KASIH ATAS RATING KAMU!*\n\n` +
    `Kamu beri: *${star} bintang*\n` +
    `Rating seller: *${avg}* ${starDisplay} (${ratings[sellerId].count} ulasan)`,
    { parse_mode: 'Markdown' }
  );

  // Notif seller
  bot.telegram.sendMessage(sellerId,
    `Pembeli beri kamu *${star} bintang*! \n` +
    `Rating kamu sekarang: *${avg}* ${starDisplay}`,
    { parse_mode: 'Markdown' }
  ).catch(() => {});

  // Notify admin
  ADMIN_IDS.forEach(id => {
    bot.telegram.sendMessage(id,
      `RATING BARU\nSeller: ${sellerId}\nRating: ${star} bintang\nRata-rata: ${avg}`,
      { parse_mode: 'Markdown' }
    ).catch(() => {});
  });
});

// === KOMPLAIN & REFUND ===

bot.action(/cek_(.+)/, async (ctx) => {
  const orderId = ctx.match[1];
  const [code, room] = Object.entries(rooms).find(([_, r]) => r.orderId === orderId) || [];
  if (!room) return ctx.answerCbQuery('Transaksi tidak ditemukan!');

  const total = room.items.reduce((a, b) => a + b.price, 0);
  const status = await checkPaymentStatus(total, orderId);

  if (status.status === 'paid') {
    room.status = 'waiting_vote';
    saveData();

    const item = room.items[0];

    const voteMsg = `*PENGECEKAN AKUN*\n\n` +
      `Item: *${escapeMarkdown(item.name)}*\n` +
      `Cek akun login & konfirmasi:\n\n` +
      `Vote kamu: (pilih tombol)`;

    // Kirim ke buyer
    const buyerMsg = await bot.telegram.sendMessage(room.buyer, voteMsg, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('Done', `vote_${code}_done`), Markup.button.callback('Not Done', `vote_${code}_notdone`)]
      ])
    });
    room.buyerVoteMsgId = buyerMsg.message_id;

    // Kirim ke seller
    const sellerMsg = await bot.telegram.sendMessage(room.seller, voteMsg, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [Markup.button.callback('Done', `vote_${code}_done`), Markup.button.callback('Not Done', `vote_${code}_notdone`)]
      ])
    });
    room.sellerVoteMsgId = sellerMsg.message_id;

    saveData();
    ctx.answerCbQuery('Pembayaran sukses! Mulai pengecekan akun.');

    let deliveryMsg = `*PEMBAYARAN SUKSES!*\n\n` +
      `*${escapeMarkdown(item.name)}*\n` +
      `${formatRupiah(item.price)}\n\n`;

    if (item.data) {
      const [email, pass] = item.data.split(':');
      deliveryMsg += `*Email:* \`${email}\`\n`;
      deliveryMsg += `*Password:* \`${pass}\`\n\n`;
    }

    deliveryMsg += `Terima kasih! Chat penjual jika ada masalah.`;

    // Kirim ke pembeli
    await bot.telegram.sendMessage(room.buyer, deliveryMsg, {
      parse_mode: 'Markdown',
      ...Markup.inlineKeyboard([
        [
          Markup.button.callback('1', `rate_${code}_1`),
          Markup.button.callback('2', `rate_${code}_2`),
          Markup.button.callback('3', `rate_${code}_3`),
          Markup.button.callback('4', `rate_${code}_4`),
          Markup.button.callback('5', `rate_${code}_5`)
        ],
        [Markup.button.callback('Chat Penjual', `chat_${code}`)]
      ])
    });

    // Kirim file jika ada
    if (item.filePath && fs.existsSync(item.filePath)) {
      const sendFn = item.fileType === 'photo' ? 'sendPhoto' : 'sendDocument';
      await bot.telegram[sendFn](room.buyer, { source: item.filePath }, {
        caption: '*File Item (Asli)*',
        parse_mode: 'Markdown'
      });
    }

    // Notifikasi ke penjual
    await bot.telegram.sendMessage(room.seller,
      `*TRANSAKSI SUKSES!*\n\n` +
      `Room: *${code}*\n` +
      `Total: ${formatRupiah(total)}\n` +
      `Item sudah dikirim ke pembeli.`,
      { parse_mode: 'Markdown' }
    );

    // History
    addToHistory(room.seller, code, 'penjual', item, total, 'completed');
    addToHistory(room.buyer, code, 'pembeli', item, total, 'completed');

    // Hapus pesan QRIS dari chat
    if (room.qrisMessageId) {
      bot.telegram.deleteMessage(room.buyer, room.qrisMessageId).catch(() => {});
    }

    // Cleanup file lokal
    if (room.qrFile) cleanupQRFile(room.qrFile);

    // Reset data room
    room.qrisMessageId = null;
    room.qrFile = null;
    room.orderId = null;
    saveData();

    // Notify admin
    ADMIN_IDS.forEach(id => {
      bot.telegram.sendMessage(id,
        `*TRANSAKSI SUKSES*\nRoom: ${code}\nTotal: ${formatRupiah(total)}`,
        { parse_mode: 'Markdown' }
      ).catch(() => {});
    });

    // Konfirmasi ke pembeli (via callback)
    ctx.answerCbQuery('Pembayaran sukses! Item dikirim.', { show_alert: true });

  } else if (status.status === 'pending') {
    ctx.answerCbQuery('Pembayaran belum masuk. Coba lagi 10 detik.', { show_alert: true });

  } else {
    ctx.answerCbQuery('Error cek pembayaran. Coba lagi.');
  }
}); // ✅ tutup di sini


bot.action(/complain_(.+)/, (ctx) => {
  const code = ctx.match[1];
  userState[ctx.from.id] = { step: 'complain', roomCode: code };
  ctx.answerCbQuery('📸 Kirim bukti gagal (screenshot error):');
  bot.telegram.sendMessage(ctx.from.id, '📸 Kirim bukti gagal (screenshot error):');
});

bot.action(/admin_resolve_(.+)_(done|refund)/, async (ctx) => {
  const code = ctx.match[1];
  const decision = ctx.match[2];
  const room = rooms[code];
  if (!room || !ADMIN_IDS.includes(ctx.from.id)) return ctx.answerCbQuery('Akses ditolak!');

  if (decision === 'done') {
    // Selesai seperti kedua 'done'
    room.status = 'completed';
    // ... (kirim data ke buyer, notif, history, cleanup vote msg)
  } else if (decision === 'refund') {
    const total = room.items.reduce((a, b) => a + b.price, 0);
    addBalance(room.buyer, total);
    addToHistory(room.buyer, code, 'pembeli', room.items[0], total, 'refunded');
    addToHistory(room.seller, code, 'penjual', room.items[0], total, 'refunded');
    delete rooms[code];
    // Notif buyer/seller/admin
    bot.telegram.sendMessage(room.buyer, 'Admin refund transaksi!');
    bot.telegram.sendMessage(room.seller, 'Admin refund transaksi!');
  }

  saveData();
  ctx.answerCbQuery(`Resolved: ${decision}`);
});

bot.action(/vote_(.+)_(done|notdone)/, async (ctx) => {
  const code = ctx.match[1];
  const vote = ctx.match[2];
  const room = rooms[code];
  
  // Validasi room & status
  if (!room || room.status !== 'waiting_vote') {
    return ctx.answerCbQuery('Pengecekan sudah selesai!', { show_alert: true });
  }

  const userId = ctx.from.id;
  if (userId !== room.buyer && userId !== room.seller) {
    return ctx.answerCbQuery('Kamu bukan peserta room ini!');
  }

  const role = userId === room.buyer ? 'buyer' : 'seller';
  const wasVote = room.vote[role]; // Simpan vote lama
  room.vote[role] = vote; // Update vote

  // === PERBAIKAN 1: Edit tombol per user (chatId + messageId) ===
  const keyboard = [
    [
      Markup.button.callback(
        room.vote[role] === 'done' ? 'Done' : 'Done',
        `vote_${code}_done`
      ),
      Markup.button.callback(
        room.vote[role] === 'notdone' ? 'Not Done' : 'Not Done',
        `vote_${code}_notdone`
      )
    ]
  ];

  const targetChatId = role === 'buyer' ? room.buyer : room.seller;
  const targetMsgId = role === 'buyer' ? room.buyerVoteMsgId : room.sellerVoteMsgId;

  try {
    await ctx.telegram.editMessageReplyMarkup(
      targetChatId,           // Chat ID (buyer/seller)
      targetMsgId,            // Message ID
      undefined,              // inline_message_id (tidak dipakai)
      { inline_keyboard: keyboard } // Keyboard baru
    );
  } catch (err) {
    console.error('[EDIT VOTE ERROR]', err.message);
  }

  ctx.answerCbQuery(`Vote kamu: ${vote === 'done' ? 'Done' : 'Not Done'}`);

  // === CEK HASIL VOTE ===
  if (room.vote.buyer && room.vote.seller) {
    const item = room.items[0];

    if (room.vote.buyer === 'done' && room.vote.seller === 'done') {
      // SELESAI
      room.status = 'completed';

      let deliveryMsg = `*AKUN BERHASIL DICEK!*\n\n` +
        `*${escapeMarkdown(item.name)}*\n` +
        `${formatRupiah(item.price)}\n\n`;

      if (item.data) {
        const [email, pass] = item.data.split(':');
        deliveryMsg += `*Email:* \`${email}\`\n` +
                       `*Password:* \`${pass}\`\n\n`;
      }
      deliveryMsg += `Transaksi selesai. Terima kasih!`;

      await bot.telegram.sendMessage(room.buyer, deliveryMsg, {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([
          [
            Markup.button.callback('1', `rate_${code}_1`),
            Markup.button.callback('2', `rate_${code}_2`),
            Markup.button.callback('3', `rate_${code}_3`),
            Markup.button.callback('4', `rate_${code}_4`),
            Markup.button.callback('5', `rate_${code}_5`)
          ]
        ])
      });

      // History
      addToHistory(room.buyer, code, 'pembeli', item, item.price);
      addToHistory(room.seller, code, 'penjual', item, item.price);

      // === PERBAIKAN 2: Hapus pesan vote DARI CHAT YANG BENAR ===
      const deletePromises = [];
      if (room.buyerVoteMsgId) {
        deletePromises.push(bot.telegram.deleteMessage(room.buyer, room.buyerVoteMsgId).catch(() => {}));
      }
      if (room.sellerVoteMsgId) {
        deletePromises.push(bot.telegram.deleteMessage(room.seller, room.sellerVoteMsgId).catch(() => {}));
      }
      await Promise.all(deletePromises);

      // Reset
      room.buyerVoteMsgId = null;
      room.sellerVoteMsgId = null;
      room.vote = null;
      saveData();

    } else {
      // KONFLIK → LAPOR ADMIN
      const conflictMsg = `*KONFLIK VOTE*\n\n` +
        `Room: *${code}*\n` +
        `Item: *${escapeMarkdown(item.name)}*\n` +
        `Buyer: ${room.vote.buyer} ( ${ room.sellerUsername } )\n` +
        `Seller: ${room.vote.seller} ( ${ room.buyerUsername } )\n\n` +
        `Silakan resolve:`;

      ADMIN_IDS.forEach(adminId => {
        bot.telegram.sendMessage(adminId, conflictMsg, {
          parse_mode: 'Markdown',
          ...Markup.inlineKeyboard([
            [
              Markup.button.callback('Approve Done', `admin_resolve_${code}_done`),
              Markup.button.callback('Refund', `admin_resolve_${code}_refund`)
            ]
          ])
        }).catch(() => {});
      });

      // Notif user
      bot.telegram.sendMessage(room.buyer, 'Vote berbeda. Menunggu keputusan admin.', { parse_mode: 'Markdown' });
      bot.telegram.sendMessage(room.seller, 'Vote berbeda. Menunggu keputusan admin.', { parse_mode: 'Markdown' });
    }
  }

  saveData();
});


// === REFUND & REJECT ===
bot.action(/refund_(.+)/, async (ctx) => {
  const code = ctx.match[1];
  const room = rooms[code];
  if (!room || room.seller !== ctx.from.id) return ctx.answerCbQuery('❌ Bukan penjual!');
  
  const total = room.items.reduce((a, b) => a + b.price, 0);
  addBalance(room.buyer, total);
  
  addToHistory(room.buyer, code, 'pembeli', room.items[0], total, 'refunded');
  addToHistory(room.seller, code, 'penjual', room.items[0], total, 'refunded');
  
  delete rooms[code];
  saveData();
  
  ctx.editMessageText(
    `✅ *KOMPLAIN DITERIMA*\n\n` +
    `📦 Room: *${code}*\n` +
    `💰 Refund: ${formatRupiah(total)}\n\n` +
    `💳 Saldo dikembalikan ke pembeli.\n` +
    `📝 Catatan: Komplain valid (akun mati/file rusak).`,
    { parse_mode: 'Markdown' }
  );
  
  bot.telegram.sendMessage(room.buyer, 
    `💰 *REFUND DITERIMA!*\n\n` +
    `📦 Room: ${code}\n` +
    `💳 Jumlah: ${formatRupiah(total)}\n` +
    `💳 Saldo sekarang: ${formatRupiah(balances[room.buyer])}\n\n` +
    `✅ Penjual mengakui item bermasalah.\n` +
    `⭐ Berikan rating jujur untuk penjual.`,
    { parse_mode: 'Markdown' }
  );

  // Notify admin
  ADMIN_IDS.forEach(adminId => {
    bot.telegram.sendMessage(adminId, `💰 *REFUND*\nRoom: ${code}\nJumlah: ${formatRupiah(total)}\nStatus: Refunded`, { parse_mode: 'Markdown' });
  });
});

bot.action(/reject_(.+)/, async (ctx) => {
  const code = ctx.match[1];
  const room = rooms[code];
  if (!room || room.seller !== ctx.from.id) return ctx.answerCbQuery('❌ Bukan penjual!');
  
  room.status = 'completed';
  saveData();
  
  ctx.editMessageText(
    `❌ *KOMPLAIN DITOLAK*\n\n` +
    `📦 Room: *${code}*\n` +
    `💰 Total: ${formatRupiah(room.items[0].price)}\n\n` +
    `📝 Alasan: Bukti tidak valid atau item berfungsi normal.\n` +
    `⚠️ Transaksi tetap selesai.`,
    { parse_mode: 'Markdown' }
  );
  
  bot.telegram.sendMessage(room.buyer, 
    `❌ *KOMPLAIN DITOLAK*\n\n` +
    `📦 Room: ${code}\n` +
    `💰 Total: ${formatRupiah(room.items[0].price)}\n\n` +
    `📝 Penjual menolak komplain. Transaksi selesai.\n` +
    `⚠️ Jika merasa dirugikan, hubungi admin.`,
    { parse_mode: 'Markdown' }
  );

  // Notify admin
  ADMIN_IDS.forEach(adminId => {
    bot.telegram.sendMessage(adminId, `❌ *KOMPLAIN DITOLAK*\nRoom: ${code}\nStatus: Rejected`, { parse_mode: 'Markdown' });
  });
});

// === STATUS ROOM ===
bot.action(/status_(.+)/, (ctx) => {
  const code = ctx.match[1];
  const room = rooms[code];
  if (!room) return ctx.answerCbQuery('❌ Room tidak ditemukan!');

  const total = room.items.reduce((a, b) => a + b.price, 0);
  const otherUser = room.users.find(u => u !== ctx.from.id);

 ctx.replyWithMarkdown(
  `📊 *STATUS ROOM ${code}*\n\n` +
  `👥 Peserta:\n` +
  `• Penjual: ${room.sellerUsername 
    ? '@' + room.sellerUsername 
    : '[' + room.sellerName + '](tg://user?id=' + room.seller + ')'}\n` +
  `• Pembeli: ${
    room.buyer
      ? (room.buyerUsername 
          ? '@' + room.buyerUsername 
          : '[' + (room.buyerName || 'User_' + room.buyer) + '](tg://user?id=' + room.buyer + ')')
      : 'Belum ada'
  }\n\n` +
  `📦 Item: ${room.items.length} (${room.items.map(i => i.name).join(', ')})\n` +
  `💰 Total: ${formatRupiah(total)}\n` +
  `📊 Status: *${room.status}*\n\n` +
  `💬 Chat dengan partner:`,
  {
      ...Markup.inlineKeyboard([
        [Markup.button.callback('💬 Chat', `chat_${code}`)],
[Markup.button.callback('Keluar', `leave_room_${code}`)],
        [Markup.button.callback('🔄 Refresh', `status_${code}`)]
      ])
    }
  );
});

bot.action(/leave_room_(.+)/, (ctx) => {
  const code = ctx.match[1];
  const room = rooms[code];
  if (!room || !room.users.includes(ctx.from.id)) return ctx.answerCbQuery('Room tidak ditemukan!');

  // Simulasi /leave
  ctx.reply('/leave').then(() => {
    // Trigger /leave command
    bot.telegram.sendMessage(ctx.from.id, '/leave');
  });
});

// === HISTORY & SALDO ===
bot.action('history', (ctx) => {
  const entries = (history[ctx.from.id] || []).slice(-10);
  if (entries.length === 0) return ctx.editMessageText('📝 *History kosong.*\n\nMulai transaksi pertama kamu!', { parse_mode: 'Markdown' });
  
  const text = entries.map((e, i) => 
    `${i+1}. *${e.itemName}*\n` +
    `💰 ${formatRupiah(e.amount)} | ${e.status}\n` +
    `📅 ${e.timestamp}`
  ).join('\n\n');
  
  ctx.editMessageText(`📝 *RIWAYAT TRANSAKSI* (${entries.length})\n\n${text}`, { parse_mode: 'Markdown' });
});

bot.action('balance', (ctx) => {
  const balance = balances[ctx.from.id] || 0;
  ctx.editMessageText(
    `💰 *SALDO AKUN*\n\n` +
    `💳 Saldo: *${formatRupiah(balance)}*\n\n` +
    `💡 Gunakan saldo untuk:\n` +
    `• Bayar transaksi\n` +
    `• Tarik saldo (hubungi admin)`,
    { parse_mode: 'Markdown' }
  );
});

// === CEK DEPOSIT ===
bot.action(/cekdep_(.+)/, async (ctx) => {
  const orderId = ctx.match[1];
  const state = userState[ctx.from.id];
  if (!state || state.orderId !== orderId) return ctx.answerCbQuery('Transaksi tidak ditemukan!');

  const status = await checkPaymentStatus(state.amount, orderId);

  if (status.status === 'paid') {
    addBalance(ctx.from.id, state.amount);
    addToHistory(ctx.from.id, 'DEPOSIT', 'deposit', { name: 'Deposit' }, state.amount);

    // Edit caption QRIS jadi sukses
    await ctx.editMessageCaption({
      caption: 
        `*DEPOSIT BERHASIL!*\n\n` +
        `Jumlah: *${formatRupiah(state.amount)}*\n` +
        `Saldo sekarang: *${formatRupiah(balances[ctx.from.id])}*\n\n` +
        `Saldo siap digunakan untuk transaksi!`,
      parse_mode: 'Markdown'
    });

    // Cleanup
    if (state.qrFile) cleanupQRFile(state.qrFile);
    delete userState[ctx.from.id];

    // Notify admin
    ADMIN_IDS.forEach(id => {
      bot.telegram.sendMessage(id,
        `*DEPOSIT MASUK*\nUser: ${ctx.from.id}\nJumlah: ${formatRupiah(state.amount)}`,
        { parse_mode: 'Markdown' }
      );
    });

  } else if (status.status === 'pending') {
    ctx.answerCbQuery('Belum ada pembayaran. Coba lagi 10 detik.', { show_alert: true });
  } else {
    ctx.answerCbQuery('Error cek deposit. Coba lagi.');
  }
});

// === CANCEL PAYMENT ===
bot.action(/cancel_(.+)/, async (ctx) => {
  const code = ctx.match[1];
  const room = rooms[code];
  if (!room) return ctx.answerCbQuery('Room tidak ditemukan!');

  const otherUser = room.users.find(u => u !== ctx.from.id);
  if (otherUser) {
    bot.telegram.sendMessage(otherUser,
      `*TRANSAKSI DIBATALKAN*\n\nRoom: ${code}\nStatus: Dibatalkan oleh partner`,
      { parse_mode: 'Markdown' }
    );
  }

  if (room.qrisMessageId && room.qrFile) {
    try {
      await ctx.editMessageCaption({
        caption: 'PEMBAYARAN DIBATALKAN\n\nTransaksi dibatalkan oleh pembeli.',
        parse_mode: 'Markdown'
      });
    } catch (err) {
      console.log('Gagal edit caption batal:', err.message);
    }
    cleanupQRFile(room.qrFile);
  }

  room.status = ctx.from.id === room.buyer ? 'item_added' : 'connected';
  room.orderId = null;
  room.qrisMessageId = null;
  room.qrFile = null;
  saveData();

  ctx.answerCbQuery('Pembayaran dibatalkan.');
});

// === LAUNCH ===
bot.launch();
console.log('🤖 Bot Rekber v5.1 SIAP JALAN!');
console.log('✅ Semua fitur aktif:');
console.log('• QRIS dengan detail fee');
console.log('• Chat system aman');
console.log('• Admin panel lengkap');
console.log('• Notifikasi real-time');
console.log('• Anti-penipuan 100%');

process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));